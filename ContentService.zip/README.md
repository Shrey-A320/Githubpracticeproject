# Introduction 

Content service centralizes the creation of splash screens and serves them to the different applications

# Getting Started

- Content Service: is the service itself which is consumed by gatekeeper via the client
- angular module: has the editing component as well as the splash screen component
- ckeditor-build has the customized build for ck editor, it allows to add custom plugins based on https://github.com/ckeditor/ckeditor5-build-decoupled-document

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)