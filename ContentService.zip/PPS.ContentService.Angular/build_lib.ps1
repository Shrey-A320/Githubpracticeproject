$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
Remove-Item -ErrorAction Ignore -Recurse $dir\lib\src
Remove-Item -ErrorAction Ignore -Recurse $dir\lib\dist
Copy-Item  -Recurse -Force $dir\ContentServiceDemo\src\app\src $dir\lib
npm install
# get published version and patch version
$path = "$dir\lib\package.json"
$packageJSON = Get-Content $path -Raw | ConvertFrom-Json
$publishedVersion =  npm show pps-ui version
if(!$publishedVersion.Equals("") -and $packageJSON.version.Split(".")[0] -le $publishedVersion.Split(".")[0] -and $packageJSON.version.Split(".")[1] -le $publishedVersion.Split(".")[1]){
$packageJSON.version = $publishedVersion;
$packageJSON | ConvertTo-Json | %{
    [Regex]::Replace($_, 
        "\\u(?<Value>[a-zA-Z0-9]{4})", {
            param($m) ([char]([int]::Parse($m.Groups['Value'].Value,
                [System.Globalization.NumberStyles]::HexNumber))).ToString() } )}| set-content $path
}
echo $packageJSON.version
cd lib
npm version patch
cd ..
npm run build:lib