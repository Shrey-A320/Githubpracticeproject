$lib=$args[0]
cd lib
Remove-Item -ErrorAction Ignore package.json
Copy-Item $lib-package.json package.json
cd ..