﻿npm install -g vsts-npm-auth --registry https://registry.npmjs.com  --always-auth false
$env:HOMEDRIVE = "C:"
$env:HOMEPATH = "\Users\" + $env:UserName
vsts-npm-auth -config .npmrc