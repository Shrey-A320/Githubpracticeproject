import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
    enableProdMode();
}

// platformBrowserDynamic().bootstrapModule(AppModule)
//     .catch(err => console.error(err));


function bootstrapFailed(reason, val) {
    const loadingEl = document.getElementsByClassName('page-loading');
    if (loadingEl.length > 0) {
        loadingEl[0].innerHTML = '<i class="icon ico-7x ico-exclamation-circle"></i>';
    }
    console.error('bootstrap-fail', reason, val);
}

const baseHref = ((document.getElementsByTagName('base')[0] || {}) as any).href || '/';

const xhr = new XMLHttpRequest();

xhr.onreadystatechange = () => {
    if (xhr.readyState !== 4) { return; }
    if (xhr.status >= 200 && xhr.status < 300) {
        const config = JSON.parse(xhr.responseText);

        if (!config || !config['ENVVAR_ENVIRONMENT']) {
            bootstrapFailed('unable to locate environment variables', config);
            return;
        }
        if (!environment.production) {
            config.ContentService_Url = "https://localhost:44332";
        }
        window['ENVVARS'] = config;
        return platformBrowserDynamic()
            .bootstrapModule(AppModule)
            .catch((err) => bootstrapFailed('catch bootstrap exception', err));

    } else {
        bootstrapFailed('fetch config.json failure', xhr);
    }
};
xhr.open('GET', baseHref + '/assets/config.json');
xhr.send();
