import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PpsBaseModule } from '@pps/base';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ContentEditorModule } from './src/content-editor/content-editor.module';
import { SplashModule } from './src/splash-screen/splash-screen.module';
import { GatekeeperInterceptor } from './gatekeeper-intercepteror';
import { GatekeeperWrapperService } from './gatekeeper-wrapper.service';
import { GatekeeperWrapperComponent } from './gatekeeper-wrapper.component';
import { FormsModule } from '@angular/forms';

import { Angulartics2RouterlessModule } from 'angulartics2/routerlessmodule';
import { Angulartics2Piwik } from 'angulartics2/piwik';

@NgModule({
    declarations: [
        AppComponent,
        GatekeeperWrapperComponent
    ],
    imports: [
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        ContentEditorModule,
        SplashModule,
        HttpClientModule,
        PpsBaseModule,
        AppRoutingModule,
        Angulartics2RouterlessModule.forRoot()
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: GatekeeperInterceptor, multi: true }, 
        GatekeeperWrapperService
    ],
    bootstrap: [
        AppComponent, 
        GatekeeperWrapperComponent
    ]
})
export class AppModule { }
