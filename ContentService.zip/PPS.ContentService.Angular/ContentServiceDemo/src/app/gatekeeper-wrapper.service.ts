import { Injectable } from '@angular/core';

@Injectable()
export class GatekeeperWrapperService {

    public userID:string = "123";
    public serviceID:string = "AU257";
    public token:string = "CTNTSRVC-TEST-38C05E9FBAD04BFDA4C6A9191CB88B9A-638814245532480942";

    constructor() {
    };

}

