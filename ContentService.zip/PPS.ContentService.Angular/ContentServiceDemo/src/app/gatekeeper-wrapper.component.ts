import { Component, OnInit } from '@angular/core';
import { GatekeeperWrapperService } from './gatekeeper-wrapper.service';

@Component({
  selector: 'gatekeeper-wrapper',
  template: `
  <div class="ui segment"> 
  <div class="xs page-title"><h2>Gatekeeper wrapper</h2></div>
  <div class="flex row block-small">
  <div class="xs-12 md-4">
      <div class="zeta block-micro">
          Token
      </div>
          <div class="ui input fluid">
              <input class="input-text" name="token"
                  [(ngModel)]="gatekeeperWrapperService.token" required>
          </div>
  </div>
  <div class="xs-12 md-4">
      <div class="zeta block-micro">
          User Id
      </div>
          <div class="ui input fluid">
              <input class="input-text" name="userID"
                  [(ngModel)]="gatekeeperWrapperService.userID" required>
          </div>
  </div>
  <div class="xs-12 md-4">
      <div class="zeta block-micro">
          Service Id
      </div>
      <div class="ui input fluid">
          <input class="input-text" name="serviceID"
              [(ngModel)]="gatekeeperWrapperService.serviceID" required>

      </div>
  </div>
</div>
</div>
  `
})
export class GatekeeperWrapperComponent implements OnInit {


  constructor(public gatekeeperWrapperService: GatekeeperWrapperService) {
  }
  ngOnInit(): void {
    
  }


}
