import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GatekeeperWrapperService } from './gatekeeper-wrapper.service';
@Injectable()
export class GatekeeperInterceptor implements HttpInterceptor {
    constructor(private gatekeeperWrapperService:GatekeeperWrapperService) { }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        request = request.clone({
            setHeaders: {
                userID: this.gatekeeperWrapperService.userID,
                serviceID: this.gatekeeperWrapperService.serviceID,
                'x-pps-token': this.gatekeeperWrapperService.token,
            }
        });
        return next.handle(request);
    }
}