import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { Splash, ApplicationContext } from '../../shared/api/content-service.module';
import { finalize } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ContentService } from '../../shared/services/content.service';

import { CustomPiwikProvider } from '../CustomPiwikProvider';
import { BaseEnvironmentService } from '@pps/base';

@Component({
  selector: 'content-splash',
  templateUrl: 'splash-screen.html',
  styleUrls: ['../../splash-screen.scss']
})
export class SplashScreenComponent implements OnInit {
  openSplash: boolean = true;
  html: string;

  @Input() application: ApplicationContext = null;
  @Input() showAfterLoad: string;

  @Output() close = new EventEmitter<any>();
  @Output() loaded = new EventEmitter<any>();

  current: number = 0;
  splashScreens: Observable<Splash[]>;
  splashLoaded:boolean = false;

  brandOverride:string;
  contentLoadedName:string;

 @ViewChild("splashContent") splashContent: ElementRef; 

  applicationContext = [
    "HAL",
    "Applications",
    "InvestorPortal",
    "AdviserPortal"
  ];

  piwikActions = {
    splashLoaded: "Splash loaded",
    splashDismissed: "Splash dismissed",
    splashSnoozed: "Splash snoozed",
    splashAction: "Splash action",
  }

  constructor(private contentService: ContentService, private piwik: CustomPiwikProvider, private environment:BaseEnvironmentService) { 
    
  }

  async ngOnInit() {
    if(this.application!=null && this.snoozeOver() && !this.checkSessionLoaded()){
      this.splashScreens = this.contentService.getSplashes(this.application).pipe(finalize(() => {
        this.emitLoaded();
        this.sessionLoaded();
        this.splashLoaded=true;

        this.piwik.configure(this.environment.vars.ENVVAR_PIWIKURL, 25);
      }));
    }else{
      this.splashLoaded=true;
      var _ = this;
      setTimeout(()=>this.emitLoaded(), 500);
      
    }
  }

  emitLoaded(): void {
    if(this.splashLoaded)
      document.querySelectorAll(this.showAfterLoad).forEach(e=>{
        (e as HTMLElement).style.display = "block";
      });
      
    this.loaded.emit()
  }

  closeSplash() {
    this.snooze();
    this.openSplash = false;
    this.contentService.viewSplash(this.application).subscribe((d) => {
      this.close.emit("closed");
      this.piwik.eventTrack(this.piwikActions.splashDismissed, { category: "Splash", name: `Splash dismissed in ${this.applicationContext[this.application]}`});
    });
  }

  get snoozeKey():string {
    return`splash_snooze_${this.application}`;
  }

  get sessionLoadedKey():string {
    return`splash_sessionLoaded_${this.application}`;
  }

  sessionLoaded(){
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate()+1)
    sessionStorage.setItem(this.sessionLoadedKey, this.sessionLoadedKey);
  }

  checkSessionLoaded(){
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate()+1)
    return sessionStorage.getItem(this.sessionLoadedKey)!=null;
  }

  snooze(){
    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate()+1)
    localStorage.setItem(this.snoozeKey, tomorrow.toString());
    this.openSplash = false;
    
  }

  snoozeClicked(){
    this.snooze();
    this.piwik.eventTrack(this.piwikActions.splashSnoozed, { category: "Splash", name: `Splash snoozed in ${this.applicationContext[this.application]}`});
  }

  snoozeOver(){
    var snoozeTo = localStorage.getItem(this.snoozeKey);
    if(snoozeTo){
      var now = new Date();
      var snoozed = new Date(Date.parse(snoozeTo));
      return now > snoozed;
    }
    return true;
  }

  trackNavSplash(nav){
    this.piwik.eventTrack(this.piwikActions.splashAction, { category: "Splash", name: `Splash navigation ${nav} in ${this.applicationContext[this.application]}`});
  }

  splashContentLaoded(name){
    this.contentLoadedName = name;
    this.piwik.eventTrack(this.piwikActions.splashLoaded, { category: "Splash", name: `Splash loaded \"${name}\" in ${this.applicationContext[this.application]}`});
  }
  splashContentDisplayed(){
    this.splashContent.nativeElement.querySelectorAll("a[href]").forEach(a => {
      a.addEventListener("click", (ev)=> {
        this.piwik.eventTrack(this.piwikActions.splashAction, { category: "Splash", name: `Splash link clicked for \"${ this.contentLoadedName }\" in ${this.applicationContext[this.application]}`});
      })
    });
  }

}
