import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GatekeeperApiModule } from 'pps-gatekeeper-api';
import { SharedModule } from '../shared/shared.module';
import { SplashScreenComponent } from './splash-screen/splash-screen.component';


@NgModule({
    imports: [
        CommonModule,
        GatekeeperApiModule,
        SharedModule
    ],
    providers: [
    ],
    declarations: [
        SplashScreenComponent
    ],
    exports: [
        SplashScreenComponent, 
        SharedModule
    ],
    entryComponents: [
        SplashScreenComponent
    ]
})
export class SplashModule {
    exports = [SplashScreenComponent];
    constructor() { 
    }
}

export { SplashScreenComponent } from './splash-screen/splash-screen.component';