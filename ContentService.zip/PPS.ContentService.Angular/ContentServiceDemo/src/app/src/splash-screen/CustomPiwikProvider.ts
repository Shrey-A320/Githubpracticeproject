import { Injectable } from '@angular/core';

import { Angulartics2 } from 'angulartics2';

declare var Matomo: any;

@Injectable({ providedIn: 'root' })
export class CustomPiwikProvider {

    private trackerUrl:string;
    private siteId:number; 

    private _tracker;
    public get tracker(): any {
        if (!this._tracker) {
            if (typeof (Matomo) === 'undefined') {
                console.warn('Piwik not found');
            }
            if (!this.trackerUrl || !this.siteId) {
                console.warn('Piwik configuration not found');
            }
            try{
                this._tracker = Matomo.getTracker(this.trackerUrl, this.siteId);

                this.angulartics2.pageTrack
                    .pipe(this.angulartics2.filterDeveloperMode())
                    .subscribe((x) => this.pageTrack(x.path));
                this.angulartics2.eventTrack
                    .pipe(this.angulartics2.filterDeveloperMode())
                    .subscribe((x) => this.eventTrack(x.action, x.properties));
            }catch(e){}
            
        }
        return this._tracker;
    }

    constructor(private angulartics2: Angulartics2) {

        this.angulartics2.setUsername
            .subscribe((x: string) => this.setUsername(x));
        this.angulartics2.setUserProperties
            .subscribe((x) => this.setUserProperties(x));

    }

    configure(trackerUrl, siteId){
        this.trackerUrl = trackerUrl;
        this.siteId = siteId;
    }

    pageTrack(path: string, location?: any) {
        try {
            this.tracker?.trackPageView(window.document.title);
        } catch (e) {
            if (!(e instanceof ReferenceError)) {
                throw e;
            }
        }
    }

    eventTrack(action: string, properties: any = {}) {
        let params = [];
        switch (action) {
           
            case 'setEcommerceView':
                params = ['setEcommerceView',
                    properties.productSKU,
                    properties.productName,
                    properties.categoryName,
                    properties.price,
                ];
                break;

            case 'addEcommerceItem':
                params = [
                    'addEcommerceItem',
                    properties.productSKU,
                    properties.productName,
                    properties.productCategory,
                    properties.price,
                    properties.quantity,
                ];
                break;

            case 'trackEcommerceCartUpdate':
                params = ['trackEcommerceCartUpdate', properties.grandTotal];
                break;

            case 'trackEcommerceOrder':
                params = [
                    'trackEcommerceOrder',
                    properties.orderId,
                    properties.grandTotal,
                    properties.subTotal,
                    properties.tax,
                    properties.shipping,
                    properties.discount,
                ];
                break;

            case 'trackGoal':
                params = [
                    'trackGoal',
                    properties.goalId,
                    properties.value,
                ];
                break;

            case 'trackSiteSearch':
                params = [
                    'trackSiteSearch',
                    properties.keyword,
                    properties.category,
                    properties.searchCount,
                ];
                break;

            default:
                // PAQ requires that eventValue be an integer, see: http://piwik.org/docs/event-tracking
                if (properties.value) {
                    const parsed = parseInt(properties.value, 10);
                    properties.value = isNaN(parsed) ? 0 : parsed;
                }

                params = [
                    'trackEvent',
                    properties.category,
                    action,
                    properties.name || properties.label, // Changed in favour of Piwik documentation. Added fallback so it's backwards compatible.
                    properties.value,
                ];
        }
        try {
            this.tracker?.trackEvent(params[1], params[2], params[3], params[4]);
        } catch (e) {
            if (!(e instanceof ReferenceError)) {
                throw e;
            }
        }
    }

    setUsername(userId: string | boolean) {
        try {
            this.tracker?.setUserId(userId);
        } catch (e) {
            if (!(e instanceof ReferenceError)) {
                throw e;
            }
        }
    }

    setUserProperties(properties: any) {
        const dimensions = this.setCustomDimensions(properties);
        try {
            if (dimensions.length === 0) {
                this.tracker?.setCustomVariable(properties.index, properties.name, properties.value, properties.scope);
            }
        } catch (e) {
            if (!(e instanceof ReferenceError)) {
                throw e;
            }
        }
    }

    private setCustomDimensions(properties: any): string[] {
        const dimensionRegex: RegExp = /dimension[1-9]\d*/;
        const dimensions = Object.keys(properties)
            .filter(key => dimensionRegex.exec(key));
        dimensions.forEach(dimension => {
            const number = Number(dimension.substr(9));
            this.tracker?.setCustomDimension(number, properties[dimension]);
        });
        return dimensions;
    }
}