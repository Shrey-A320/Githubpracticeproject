import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule } from '@angular/forms';

import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { SplashEditorComponent } from './splash-editor/splash-editor.component';
import { SplashListComponent } from './splash-list/splash-list.component';
import { SearchBoxComponent } from './search-bar/searchbox.component';
import { ContentEditorComponent } from './content-editor.component';
import { GatekeeperApiModule } from 'pps-gatekeeper-api';
import { SharedModule } from '../shared/shared.module';
import { SplashPreviewComponent } from './splash-preview/splash-preview.component';
import { CkEditorComponent } from './splash-editor/ck-editor.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';

@NgModule({
    imports: [
        CommonModule,
        NgxDatatableModule,
        NgSelectModule,
        FormsModule,
        GatekeeperApiModule,
        SharedModule,
        CKEditorModule
    ],
    providers: [
    ],
    declarations: [
        SplashEditorComponent,
        SplashListComponent,
        SearchBoxComponent,
        ContentEditorComponent,
        SplashPreviewComponent, 
        CkEditorComponent
    ],
    exports: [
        SplashEditorComponent,
        SplashListComponent,
        SearchBoxComponent,
        ContentEditorComponent,
        SplashPreviewComponent
    ],
    entryComponents: [
        ContentEditorComponent
    ]
})
export class ContentEditorModule {
    constructor() { 
    }
}

export { ContentEditorComponent } from './content-editor.component';