import { Component, OnInit, ViewChild } from '@angular/core';
import { Splash } from '../shared/api/content-service.module';
import { SplashListComponent } from './splash-list/splash-list.component';


@Component({
    selector: 'content-editor',
    templateUrl: './content-editor.component.html',
    styleUrls: ['./content-editor.component.scss']
})
export class ContentEditorComponent {
    
    listMode:boolean = true;

    toEditSplash:Splash;
    cloned:boolean;

    @ViewChild(SplashListComponent) list: SplashListComponent;

    constructor() {

    }
    
    newClicked(event){
        this.cloned = false;
        this.listMode = false;
    }

    editSplash(event){
        this.cloned = false;
        this.toEditSplash=event;
        this.listMode = false;
    }

    cloneSplash(event){
        this.cloned = true;
        this.toEditSplash=event;
        this.listMode = false;
    }

    saved(event){
        if(this.toEditSplash)
            for(var i in event)
                this.toEditSplash[i]=event[i];

        this.showList();
    }

    cancelled(event){
        this.showList();
    }

    showList(){
        this.list.refreshList();
        this.toEditSplash=null;
        this.listMode = true;
    }

}   