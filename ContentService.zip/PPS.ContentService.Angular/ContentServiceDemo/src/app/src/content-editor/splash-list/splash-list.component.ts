import { Component, Output, EventEmitter, ViewChild, AfterViewInit } from '@angular/core';
import { combineLatest, BehaviorSubject, Subscription } from 'rxjs';
import { switchMap, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { LoaderComponent } from '../../shared/loader/loader.component';
import { ContentService } from '../../shared/services/content.service';
import { Constants } from '../../shared/ceDatePipe';
import { Splash, Status } from '../../shared/api/content-service.module';

@Component({
    selector: 'splash-list',
    styleUrls: ['splash-list.scss'],
    templateUrl: 'splash-list.html'
})
export class SplashListComponent implements AfterViewInit {

    data: Splash[];
    isSearching = false;
    pageSize = 10;
    continuationToken: string;
    previewId: string;
    preview: boolean;

    @Output() editClicked = new EventEmitter<Splash>();
    @Output() newClicked = new EventEmitter();
    @Output() cloneClicked = new EventEmitter();

    publishedValidation;

    searchTerm: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    pageNumber: BehaviorSubject<number> = new BehaviorSubject<number>(null);
    statusFilter: BehaviorSubject<Status> = new BehaviorSubject<Status>(null);

    private subscriptions: Subscription[] = [];

    private lastSearchTerm: string;
    private lastStatus: Status;

    @ViewChild(LoaderComponent) private loaderComponent: LoaderComponent;
    loading = false;
    dateformat: string = Constants.DATE_TIME_FMT;

    constructor(private contentService: ContentService) {
    }
    ngAfterViewInit(): void {
        //this.refreshList();

        const sub = combineLatest(
            this.searchTerm.pipe(debounceTime(500), distinctUntilChanged()),
            this.pageNumber,
            this.statusFilter
        ).pipe(
            switchMap(vals => {
                if (this.lastSearchTerm !== vals[0] || this.lastStatus !== vals[2]) {
                    this.continuationToken = null;
                    this.isSearching = true;
                    this.data = [];
                }
                this.lastSearchTerm = vals[0];
                this.lastStatus = vals[2];
                this.loading = true;
                const currentPage = ((vals[1] || 1) - 1) * this.pageSize;
                //const ordering: Sort = vals[2] || Object.assign({});
                //return this.clientsService.SearchClients(this.adviserId, vals[0], currentPage, this.pageSize, false, ordering.prop, ordering.dir);
                return this.contentService.getSplashByServiceId(this.continuationToken, this.pageSize, this.lastSearchTerm, this.lastStatus);
            })
        ).subscribe(data => {
            this.isSearching = false;
            this.data = (this.data || []).concat(data.items);
            this.continuationToken = data.continuationToken;
            //this.clientsSubject.next(this.paginatePipe.transform(data.items, { itemsPerPage: this.pageSize, currentPage: this.pageNumber.getValue(), totalItems: data.totalClients }));
            this.loading = false;
        });

        this.subscriptions.push(sub);


    }
    deleteSplash(splash: Splash) {
        const r = confirm('Are you sure you want to delete this splash screen?');
        if (r === true) {
            this.loading = true;
            this.contentService.deleteSplash(splash.id).subscribe(d => {
                this.refreshList();
            });
        }
    }

    cloneSplash(splash: Splash) {
        const copy = JSON.parse(JSON.stringify(splash)) as Splash;
        copy.name += '(cloned)';
        this.cloneClicked.emit(copy);
    }

    refreshList() {
        this.continuationToken = null;
        this.data = [];
        this.pageNumber.next(0);
    }

    setFilter(status: Status) {
        this.continuationToken = null;
        this.data = [];
        this.statusFilter.next(status);
    }

    loadMore() {
        this.pageNumber.next(this.pageNumber.getValue());
    }

    publishSplash(splash: Splash) {

        const r = confirm('Are you sure you want to publish this splash screen?');
        if (r === true) {
            this.loading = true;
            this.contentService.publishSplash(splash.id).subscribe(d => {
                if (d.success) {
                    return this.refreshList();
                }

                this.loading = false;
                this.publishedValidation = Object.keys(d.messages).map(k => d.messages[k]);
                setTimeout(() => this.publishedValidation = null, 5000);
            });
        }
    }

    statusLabels = [
        'Draft',
        'Pending',
        'Live',
        'Expired',
    ];

    getDaysLabel(splash: Splash) {

        const getHoursBetween = (d1: Date, d2: Date) => {
            const one_hour = 1000 * 60 * 60;
            return Math.round(d1.getTime() - d2.getTime()) / (one_hour);
        }

        const status = splash.status | 0;
        const logic = [null,
            {
                lbl: 'Goes Live in',
                hours: () => getHoursBetween(new Date(splash.from), new Date())
            }, {
                lbl: 'Ends in',
                hours: () => getHoursBetween(new Date(splash.to), new Date())
            }, null];
        if (logic[status]) {
            let hours = logic[status].hours();
            const days = Math.round(hours / 24);
            if (days) {
                return `${logic[status].lbl} ${days} ${days === 1 ? 'day' : 'days'}`;
            }

            hours = Math.round(hours);
            return `${logic[status].lbl} ${hours ? hours : 'less than an'} ${hours > 1 ? 'hours' : 'hour'}`;
        }
        return null;
    }

    previewSplash(splash: Splash) {
        this.previewId = splash.id;
        this.preview = true;
    }

}
