//import { PaginatePipe } from 'ngx-pagination';
import { Component, OnInit, OnDestroy, Output, Input, TemplateRef, ContentChild, ViewChild, HostListener, ElementRef } from "@angular/core";
import { BehaviorSubject, Observable, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, skip } from "rxjs/operators";
import { EventEmitter } from "@angular/core";

export interface ISearchDelegate {
    performSearch(searchText: string, skip?: number, take?: number): Observable<any>;
}

@Component({
    templateUrl: './searchbox.component.html',
    styleUrls: ['./searchbox.component.scss'],
    selector: 'searchbox'
})
export class SearchBoxComponent implements OnInit, OnDestroy {
    // for non-dropdown searchbox
    @Output() searchTerm: BehaviorSubject<string> = new BehaviorSubject<string>(null);
    @Input() isSearching: boolean;

    // For Dropdown enabled searchbox
    @Output() itemSelected: EventEmitter<any> = new EventEmitter();
    @Output() dropdownOpenClose: EventEmitter<boolean> = new EventEmitter();

    @Input() isDropDownEnabled: boolean;
    @Input() isPaginationEnabled: boolean = true;
    @Input() searchDelegate: ISearchDelegate;
    @Input() placeholder: string;
    @Input() maxPageSize: number = 0;
    @Input() condensed: boolean;
    @Input() searchOnLoad: boolean;
    @Input() disabled?: boolean = false;
    @Input() autoClose: boolean = true;

    @ContentChild('searchFilters') searchFiltersTmpl: TemplateRef<any>;
    @ContentChild('searchItemContent') searchItemContentTmpl: TemplateRef<any>;

    searchText: string;
    isDropDownOpen: boolean;
    results: any[] = [];

    hasSearched: boolean;

    totalItems: number = 0;
    pageNumber: BehaviorSubject<number> = new BehaviorSubject<number>(0);

    constructor() { }

    ngOnInit(): void {
        if (this.isDropDownEnabled) {
            /*this.searchTerm.pipe(
                distinctUntilChanged(),
                debounceTime(500),
                skip(1),
                switchMap(n => {
                    if (n != null && n.trim().length > 0) {
                        this.isSearching = true;
                        this.hasSearched = true;
                        return this.searchDelegate.performSearch(n, 0, this.maxPageSize);
                    } else return of(null);
                })
            ).subscribe(n => this.handleSearchResult(n, 0));

            this.pageNumber.pipe(
                skip(1),
                switchMap(n => {
                    this.isSearching = true;
                    return this.searchDelegate.performSearch(this.searchTerm.getValue(), (n - 1) * this.maxPageSize, this.maxPageSize);
                })
            ).subscribe(n => this.handleSearchResult(n, this.pageNumber.getValue()));*/
        }
        if (this.searchOnLoad) this.searchTerm.next("");
    }
/*
    handleSearchResult = (n: Contracts.PagedQueryResult<any>, pageNum: number) => {
        this.isSearching = false;
        this.isDropDownOpen = true;
        this.dropdownOpenClose.emit(true);

        if (n != null) {
            this.totalItems = n != null && n.items != null ? n.totalResults : 0;
            this.results =
                this.maxPageSize > 0 && n.items != null && this.isPaginationEnabled
                    ? this.paginate.transform(n.items, { itemsPerPage: this.maxPageSize, currentPage: pageNum, totalItems: n.totalResults })
                    : n.items;
        }
    }*/

    pageChanged = (page: number) => this.pageNumber.next(page);

    onSearchItemSelected(searchItem: any): void {
        this.itemSelected.emit(searchItem);
        this.searchText = '';

        if (this.autoClose) {
            this.isDropDownOpen = false;
            this.dropdownOpenClose.emit(false);
        }
    }

    onSearchBoxFocus(): void {
        if (this.isDropDownEnabled) {
            this.isDropDownOpen = true;

            if (this.results && this.results.length > 0)
                this.dropdownOpenClose.emit(true);
        }
    }

    onLostFocus(): void {
        // TO DO : probably move to a directive or something as do not want
        // timeouts in component code..
        setTimeout(() => {

            if (this.autoClose || !this.results || this.results.length < 1) {
                this.isDropDownOpen = false;
                this.dropdownOpenClose.emit(false);
            }
        }, 150);
    }

    closeSearch() {
        this.isDropDownOpen = false;
        this.dropdownOpenClose.emit(false);
    }

    ngOnDestroy(): void {
        this.isDropDownOpen = false;
        this.dropdownOpenClose.emit(false);
    }
}