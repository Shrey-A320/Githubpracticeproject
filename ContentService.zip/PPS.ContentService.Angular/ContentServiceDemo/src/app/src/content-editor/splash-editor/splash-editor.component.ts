import { Component, Output, EventEmitter, Input, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import * as momentImported from 'moment'; const moment = momentImported;
import { Splash, UserLevelContext, ApplicationContext, RegionContext, ServiceAccountType } from '../../shared/api/content-service.module';
import { BehaviorSubject, Observable, of, concat, Subject } from 'rxjs';
import { LoaderComponent } from '../../shared/loader/loader.component';
import { ContentService } from '../../shared/services/content.service';
import { CkEditorComponent } from './ck-editor.component';
import { BrandingService } from '../../shared/services/branding.service';
import { distinctUntilChanged, switchMap, tap, catchError, map } from 'rxjs/operators';
import { BrandKeySearchResult } from 'pps-gatekeeper-api';

@Component({
    selector: 'splash-editor',
    styleUrls: ['splash-editor.scss', '../../splash-screen.scss'],
    templateUrl: 'splash-editor.html'
})
export class SplashEditorComponent implements AfterViewInit, OnInit {
    @Input() public splash:Splash;
    @Input() public cloned:boolean;
    @Input() public publishValidation = {};

    @Output() saved = new EventEmitter<Splash>();
    @Output() cancelled = new EventEmitter();

    loading = false;
    @ViewChild(CkEditorComponent) private editorInstance: CkEditorComponent;

    public preview:boolean = false;
    public brandingSearchError:string;

    apps: BehaviorSubject<ApplicationContext[]> = new BehaviorSubject<ApplicationContext[]>([]);
    appValues: { [key: number]: string} = {0: "Reporting & administration", 1:"Applications Portal", 2:"Investor Protal",3:"Adviser Portal" };
    appValuesForSelect:any[];

    usrLevels: BehaviorSubject<UserLevelContext[]> = new BehaviorSubject<UserLevelContext[]>([]);
    usrLevelsValues: { [key: number]: string} = {0: "Investor", 1:"Adviser", 2:"Administrator", 5:"Model Manager" };
    usrLevelsValuesForSelect:any[];

    regions: BehaviorSubject<RegionContext[]> = new BehaviorSubject<RegionContext[]>([]);
    regionValues: { [key: number]: string} = {0: "Australia", 1:"UK", 2:"Plum" };
    regionValuesForSelect:any[];

    serviceTypes: BehaviorSubject<ServiceAccountType[]> = new BehaviorSubject<ServiceAccountType[]>([]);
    serviceTypeValues: { [key: number]: string} = {0: "All", 1:"VMA", 2:"SMA", 3:"VMA Only", 4:"SMA Only"  };
    serviceTypeValuesForSelect:any[];

    excludedServices: BehaviorSubject<string[]> = new BehaviorSubject<string[]>([]);
    excludedServiceValues: { [key: string]: string} = {
        "AU1458": "Ventura",
        "AU1214": "ANZ",
        "AU63": "Morgan Stanley (AU63)",
        "AU2019": "Morgan Stanley (AU2019)",
        "AU904": "Powerwrap (904)",
        "AU1123": "Powerwrap (1123)",
        "AU2": "Shaw and Partners",
        "AU1632": "JBWere"
    };
    excludedServiceValuesForSelect:any[];

    brands:Observable<BrandKeySearchResult[]>;
    colors:{
        label,
        color
    }[];

    constructor(private contentService: ContentService, private brandingService:BrandingService) {
    }
    brandsLoading = false;
    brandInput = new Subject<string>();

    ngOnInit(): void {
        this.appValuesForSelect = this.getItems(this.appValues);
        this.usrLevelsValuesForSelect = this.getItems(this.usrLevelsValues);
        this.regionValuesForSelect = this.getItems(this.regionValues);
        this.serviceTypeValuesForSelect = this.getItems(this.serviceTypeValues);
        this.excludedServiceValuesForSelect = this.getItemsStringId(this.excludedServiceValues);

        if(this.splash==null){
            this.splash = {applications:[], userLevels:[], regions:[], excludedServices:[]} as Splash;
        }
        //this.selectBrand();
        this.brands = concat(
            of([]), // default items
            this.brandInput.pipe(
                distinctUntilChanged(),
                tap(() => {
                    this.brandsLoading = true;
                    this.brandingSearchError = null;
                }),
                switchMap(term => this.brandingService.searchBrand(term).pipe(
                    map(els=> els.map(b=>b)),
                    catchError(() => of([])), // empty list on error
                    tap(() => this.brandsLoading = false)
                ))
            )
        );
    }

    ngAfterViewInit(): void {
         if(this.splash.id){
            this.loading = true;
             this.contentService.getSplash(this.splash.id).subscribe(s=>{
                if(this.cloned){
                    s.id = null;
                    s.name = this.splash.name;
                    s.status = 0;
                }
                 this.splash = s;
                 this.splash.excludedServices = s.excludedServices || [];
                 this.loading = false;
                 this.editorInstance.setContent(this.splash.content||"");
                 this.selectBrand(this.splash.brandOverride);
                 this.dateValidation("from");
                 this.dateValidation("to");
             });
         }
    }

    async previewSplash(){
        this.splash.content = await this.getContent();
        this.preview = true;
    }

    public async saveSplash(closeAfter=false){
        if(!this.checkNameDescrition())
            return;
        this.loading = true;
        this.splash.content = await this.getContent();
        this.contentService.upsertSplash(this.splash)
            .subscribe(res=> {
                this.splash.id = res;
                this.loading = false;
                if(closeAfter)
                    this.saved.emit(this.splash);
            });
    }

    private checkNameDescrition(){
        this.publishValidation['name'] = this.splash.name?null:"A name must be provided";
        this.publishValidation['description'] = this.splash.description?null:"A description must be provided";
        return this.splash.name && this.splash.description;
    }

    async publishSplash(splash:Splash){

        var r = confirm("Are you sure you want to publish this splash screen?");
        if (r == true) {
            this.loading = true;
            this.splash.content = await this.getContent();
            this.contentService.publishSplash(this.splash.id).subscribe(d=> {
                this.loading = false;
                if(d.success)
                    this.saved.emit(this.splash);
                this.publishValidation = d.messages;
            });
        }
    }

    dateValidation(where: string) {
        switch (where) {
            case 'from': this.splash.from = this.contentService.toDateStringFlex(this.splash.from);
            case 'to': this.splash.to = this.contentService.toDateStringFlex(this.splash.to);
        }
    }

    getKeys(dictionary : { [key: number]: string} ): number[]{
        return Object.keys(dictionary).map(id=> parseInt(id));
    }

    getStringKeys(dictionary : { [key: string]: string} ): string[]{
        return Object.keys(dictionary);
    }

    getItems(dictionary : { [key: number]: string}):any[]{
        return Object.keys(dictionary).map(id=> {
           return {id: parseInt(id),
           label: dictionary[id]};
        });
    }

    getItemsStringId(dictionary : { [key: string]: string}):any[]{
        return Object.keys(dictionary).map(id=> {
           return {id: id,
           label: dictionary[id]};
        });
    }

    isChecked(elements:number[], element:number){
        return elements.find(e=>e==element)!=null;
    }

    async getContent():Promise<string>{
        return await this.editorInstance.getContent();
    }



    async selectBrand(brandId=null){
        this.loading = true;
        var content = await this.editorInstance.getContent();
        this.brandingService.getBrandColors(brandId).subscribe(cols => {
            this.colors = Array.from(cols).slice(0, 10)
            .map(col => {
                return {
                    label:col[0],
                    color:col[1]
                };
            });
        }, () => {
            this.brandingSearchError = "An error occured when selecting the branding override."
            this.splash.brandOverride = null;
            this.loading = false;
        }, ()=> {
            this.editorInstance.colors = this.colors;
            this.editorInstance.reset();
            this.loading = false;
            this.editorInstance.setContent(content);
        } );
    }

}
