import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import * as DecoupledEditor from 'pps-ckeditor/ckeditor.js';
import * as momentImported from 'moment'; const moment = momentImported;
import { EditorConfig } from './splash-editor.config';
import { BrandingService } from '../../shared/services/branding.service';
import { LoaderComponent } from '../../shared/loader/loader.component';


@Component({
    selector: 'ck-editor',
    template: `
    <loader [minHeight]="400">
    <ckeditor *ngIf="configLoaded" [editor]="Editor" [config]="config" (ready)="onReady($event)"></ckeditor>
    </loader>
    `
})
export class CkEditorComponent implements OnInit {

    private _colors:[];

    @Input() 
    public set colors(col){
        this._colors = col;
        this.setBrandingColors();
    }

    private editorInstance;
    public Editor = DecoupledEditor;
    public config = EditorConfig.config;
    private data;
    configLoaded:boolean=true;


    constructor(private _elementRef : ElementRef) { 
    }

    ngOnInit(): void {
    
    }

    onReady(editor){
        this.editorInstance = editor;

        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
        editor.execute( 'fontFamily' );
        editor.execute( 'fontSize' , { value: 10 });
        this.editorInstance.setData(this.data||"");
    }

    
    isDataURL(s) {
        var checkRegExp = /^\s*data:([a-z]+\/[a-z]+(;[a-z\-]+\=[a-z\-]+)?)?(;base64)?,[a-z0-9\!\$\&\'\,\(\)\*\+\,\;\=\-\.\_\~\:\@\/\?\%\s]*\s*$/i;
        return !!s.match(checkRegExp);
    }

    setBrandingColors(){
        this.config.fontColor.colors = this._colors;
        this.config.fontBackgroundColor.colors = this._colors;
    }

    public setContent(data:string){
        this.data = data;
        if(this.editorInstance)
            this.editorInstance.setData(this.data||"");
    }

    public async getContent():Promise<string>{
        var data = this.editorInstance.getData();
        var div = document.createElement("div");
        div.innerHTML = data;
        this.preProcessLinks(div);
        await this.preProcessUrlImages(div);
        return div.innerHTML;
    }

    private async preProcessUrlImages(div){
        var imgs = this._elementRef.nativeElement.querySelectorAll("figure.image>img");
        var copiedImages = div.querySelectorAll("figure.image>img");
        for(var i=0;i<imgs.length;i++){
            var img = imgs[i] as HTMLImageElement;
            if(!this.isDataURL(img.src)){
                let dataUrl = await new Promise<string>(resolve => {
                    img.onload = () => {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        canvas.width = img.naturalWidth;
                        canvas.height = img.naturalHeight;
                        ctx.drawImage(img, 0, 0);
                        resolve(canvas.toDataURL());
                    }
                    img.crossOrigin = 'Anonymous';
                });
                var copiedImage = copiedImages[i] as HTMLImageElement;
                img.src = dataUrl;
                copiedImage.src = dataUrl;
            }
        }
    }

    private preProcessLinks(div){
        var links = div.querySelectorAll("a");
        for(var i=0;i<links.length;i++){
            links[i].target = "_blank";
        }
    }

    public reset(){
        this.configLoaded = false;
        setTimeout(()=> this.configLoaded=true, 200 );
    }

}
