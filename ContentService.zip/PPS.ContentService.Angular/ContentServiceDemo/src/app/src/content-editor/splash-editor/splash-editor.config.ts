
export class EditorConfig{
    
    public static config = { 
        //toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ],
        heading: {
            options: [
                { model: 'heading1', view: {
                    name: 'h1',
                    classes: 'heading'
                }, title: 'Heading 1', class: 'ck-heading_1' },
                { model: 'heading2',view: {
                    name: 'h2',
                    classes: 'heading'
                }, title: 'Heading 2', class: 'ck-heading_2' },
                { model: 'heading3',view: {
                    name: 'h3',
                    classes: 'heading'
                }, title: 'Heading 3', class: 'ck-heading_3' },
                { model: 'paragraph_0', view: {
                    name: 'h4',
                    classes: 'paragraph_0'
                }, title: 'Paragraph', class: 'ck-paragraph_0' },
                { model: 'paragraph_1', view: {
                    name: 'h4',
                    classes: 'paragraph_1'
                }, title: 'Paragraph 1', class: 'ck-paragraph_1' },
                { model: 'paragraph_2', view: {
                    name: 'h4',
                    classes: 'paragraph_2'
                }, title: 'Paragraph 2', class: 'ck-paragraph_2' },
                { model: 'paragraph_3', view: {
                    name: 'h4',
                    classes: 'paragraph_3'
                }, title: 'Paragraph 3', class: 'ck-paragraph_3' },
                { model: 'button_1', view: {
                    name: 'h4',
                    classes: 'primaryButton'
                }, title: 'Primary button', class: 'primaryButton' },
                { model: 'button_2', view: {
                    name: 'h4',
                    classes: 'secondaryButton'
                }, title: 'Secondary button', class: 'secondaryButton' }
            ]
        },
        fontFamily: {
            options: [
                'Roboto',
                'PlayfairDisplay'
            ]

        }, fontSize: {
            options: [
                9,
                11,
                13,
                'default',
                17,
                19,
                21,
                25,
                33
            ],
            supportAllValues: true
        },
        fontColor: {
            colors: [
                {
                    color: 'rgb(225, 8, 136)',
                    label: 'Primary'
                },
                {
                    color: 'rgb(172, 190, 212)',
                    label: 'Secondary'
                },
                {
                    color: 'rgb(30, 22, 86)',
                    label: 'Brand'
                },
                {
                    color: 'rgb(0, 0, 0)',
                    label: 'Black'
                },
                {
                    color: 'hsl(120, 75%, 60%)',
                    label: 'Green'
                }
            ]
        },
        fontBackgroundColor:{
            colors: [
                {
                    color: 'rgb(225, 8, 136)',
                    label: 'Primary'
                },
                {
                    color: 'rgb(172, 190, 212)',
                    label: 'Secondary'
                },
                {
                    color: 'rgb(30, 22, 86)',
                    label: 'Brand'
                },
                {
                    color: 'rgb(0, 0, 0)',
                    label: 'Black'
                },
                {
                    color: 'hsl(120, 75%, 60%)',
                    label: 'Green'
                }
            ]
        },
        link: {
            addTargetToExternalLinks: true
        },
        image: {
			upload:  {types: [ 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tiff' ]}
        }
    };

}
