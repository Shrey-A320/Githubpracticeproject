import { Component, OnInit, Input, ViewChild, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { finalize, map } from 'rxjs/operators';
import { LoaderComponent } from '../../shared/loader/loader.component';
import { ContentService } from '../../shared/services/content.service';

@Component({
  selector: 'splash-preview',
  styleUrls: ['../../splash-screen.scss'],
    templateUrl: 'splash-preview.html'
})
export class SplashPreviewComponent implements AfterViewInit {
  @Input() id: string = null;
  @Input() splashHTML: string = null;
  
  @Output() close = new EventEmitter();

  @ViewChild(LoaderComponent) private loaderComponent: LoaderComponent;

  @Input() brandId:string;

  constructor(private contentService: ContentService){
  }

  async ngAfterViewInit() {
    this.loaderComponent.hide();
    if(this.id){
      this.loaderComponent.show();
      this.contentService.getSplash(this.id)
        .pipe(map(s=>  s), finalize(()=>this.loaderComponent.hide()))
        .subscribe(c=> {
          this.loaderComponent.hide();
          this.splashHTML = c.content;
          this.brandId = c.brandOverride;
        });
    }
    
  }

}
