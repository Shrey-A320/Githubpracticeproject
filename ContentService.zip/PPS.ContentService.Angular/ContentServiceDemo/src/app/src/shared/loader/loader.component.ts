import { Component, OnDestroy, Input, AfterViewInit, OnInit } from "@angular/core";
import { Subscription, Observable } from 'rxjs';
import { LoaderService, LoaderState } from './loader.service';


@Component({
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss'],
    selector: 'loader',
    providers: [
        LoaderService
    ]
})

export class LoaderComponent implements OnInit, OnDestroy {

    isVisible = false;
    private subscription: Subscription;
    @Input() minHeight?: number;
    @Input() isReady?: Observable<boolean>;
    @Input() waitingOn?: Observable<any>;
    @Input() opacity?: number;
    @Input() size?: number;

    height: string;

    constructor(private loaderService: LoaderService) { }

    show() {
        this.loaderService.show();
    }

    hide() {
        this.loaderService.hide();
    }

    ngOnInit(): void {
        this.height = (this.minHeight === null ? 0 : this.minHeight) + 'px';
        this.opacity = (this.opacity == null ? 0.75 : this.opacity);
        this.subscription = this.loaderService.loaderState
            .subscribe((state: LoaderState) => {
                var _ = this;
                setTimeout( () => this.isVisible = state.show, 100 );
                
            });

        if (this.waitingOn) {
            this.show();
            this.waitingOn
                .subscribe(_ => {
                    this.hide();
                });
        }
        
        if (this.isReady) {
            this.isReady.subscribe(_ => {
                if (_)
                    this.hide();
                else {
                    this.show();
                }
            });
        }

    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}
