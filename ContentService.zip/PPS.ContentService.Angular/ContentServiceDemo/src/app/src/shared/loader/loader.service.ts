import { Injectable, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class LoaderService {

    private loaderSubject: BehaviorSubject<LoaderState> = new BehaviorSubject<LoaderState>(<LoaderState>{ show: false });

    @Output() loaderState = this.loaderSubject.asObservable();

    constructor() {}

    show() {
        this.loaderSubject.next(<LoaderState>{ show: true });
    }

    hide() {
        this.loaderSubject.next(<LoaderState>{ show: false });
    }
}


export interface LoaderState {
    show: boolean;
}