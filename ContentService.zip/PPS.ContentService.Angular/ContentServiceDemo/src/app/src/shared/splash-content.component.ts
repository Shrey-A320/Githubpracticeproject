import { Component, Input, ViewChild, AfterViewInit, Output, EventEmitter, ElementRef } from '@angular/core';
import { finalize, map } from 'rxjs/operators';
import { ContentService } from './services/content.service';
import { LoaderComponent } from './loader/loader.component';
import { ApplicationContext } from '../shared/api/content-service.module';
import { Observable } from 'rxjs';

@Component({
  selector: 'splash-content',
  template: `
    <loader [minHeight]="400">
    <div #content [innerHTML]="splashHTML | async | safeHtml"></div>
    </loader>
  `
})
export class SplashContentComponent implements AfterViewInit {
  @Input() id: string = null;
  @Input() application: ApplicationContext = null;
  
  @ViewChild(LoaderComponent) private loaderComponent: LoaderComponent;
  @Output() contentLoaded: EventEmitter<any> = new EventEmitter();
  @Output() contentDisplayed: EventEmitter<any> = new EventEmitter();
  

  @ViewChild("content") content: ElementRef; 
  splashHTML: Observable<string>;
  _observer: MutationObserver;

  constructor(private contentService: ContentService) {
  }

  async ngAfterViewInit() {

    this._observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation, index) => {
        if (mutation.type === 'childList') {
          this.contentDisplayed.emit();
        }
      });
    });
    this._observer.observe(
      this.content.nativeElement,
      { attributes: true, childList: true, characterData: true }
    );

    if(this.id){
      this.loaderComponent.show();
      this.splashHTML = this.contentService.getCachedSplash(this.application, this.id)
        .pipe(map(s=> {
          this.contentLoaded.emit(s);
          return s.content;

        } ), finalize(()=>{
          this.loaderComponent.hide();
        }));
    }
    
  }

}
