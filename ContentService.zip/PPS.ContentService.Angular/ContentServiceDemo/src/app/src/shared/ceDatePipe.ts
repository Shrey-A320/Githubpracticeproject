import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'ceDate'
})
export class CeDatePipe extends DatePipe implements PipeTransform {
    transform(value: any, args?: any): any {
        return super.transform(value, args || Constants.NG_DATE_FMT);
    }

}
export class Constants {
    static readonly NG_DATE_FMT = 'd MMM yyyy';
    static readonly MM_DATE_FMT = 'DD MMM YYYY';
    static readonly DATE_TIME_FMT = 'd MMM yyyy  HH:mm';
  }
