import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoaderService } from '../shared/loader/loader.service';
import { LoaderComponent } from '../shared/loader/loader.component';
import { ContentService } from '../shared/services/content.service';
import { SafeHtmlPipe } from '../shared/SafeHtmlPipe';
import { CeDatePipe } from './ceDatePipe';
import { SplashContentComponent } from './splash-content.component';
import { BrandingService } from './services/branding.service';
import { SplashStyleComponent } from './splash-style.component';
import { ContentServiceModule } from './api/content-service.module';

@NgModule({
    imports: [
        CommonModule, 
        ContentServiceModule
    ],
    providers: [
        ContentService,
        BrandingService,
        LoaderService,
        CeDatePipe
    ],
    declarations: [
        LoaderComponent,
        SafeHtmlPipe,
        CeDatePipe,
        SplashContentComponent, 
        SplashStyleComponent
    ],
    exports: [
        LoaderComponent,
        SafeHtmlPipe,
        CeDatePipe,
        SplashContentComponent, 
        SplashStyleComponent
    ]
})
export class SharedModule {
    constructor() { 
    }
}