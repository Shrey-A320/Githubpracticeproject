import { Component, ViewChild, ElementRef, AfterViewInit, Input } from '@angular/core';

import { BrandingService } from './services/branding.service';

@Component({
  selector: 'splash-style',
  template: `
  <link rel="stylesheet" #linkElement type="text/css">
  `
})
export class SplashStyleComponent implements AfterViewInit {
  @ViewChild("linkElement") private linkElement: ElementRef;
    
  brandingUrl:string;

  private _brandId:string;
  @Input() 
  public set brandId(id:string){
    this._brandId = id;
    this.setStyleUrl();
  }

  constructor(brandingService: BrandingService) { 
    this.brandingUrl = brandingService.brandingUrl;
  }

  ngAfterViewInit() {
    this.setStyleUrl();
  }

  setStyleUrl(){
    if(this.linkElement)
      this.linkElement.nativeElement.href=`${this.brandingUrl}/styles/splash/${this._brandId||""}`;
  }

}
