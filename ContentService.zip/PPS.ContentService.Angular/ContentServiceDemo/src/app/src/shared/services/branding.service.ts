import { Injectable } from '@angular/core';
import { BrandingService as Bs, BrandKeySearchResult } from 'pps-gatekeeper-api';
import { Observable } from 'rxjs';
import { BaseEnvironmentService } from '@pps/base';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class BrandingService {

    private brandColors: Map<string, string>;
    private themes: { [key: string]: string[] };
    private userAvatarTheme: string[];

    public brandingUrl:string;

    constructor(private brandingService: Bs, private environment: BaseEnvironmentService) {
        if(this.environment.vars.ENVVAR_BRANDURL == null) {
            throw("Branding Url has not been defined as 'ENVVAR_BRANDURL' in the BaseEnvironmentService.");
        }
        this.brandingUrl = this.environment.vars.ENVVAR_BRANDURL;
    };

    public getBrandColors(brandId=null):Observable<Map<string, string>>{
        return (brandId?
        this.brandingService.getBrand(brandId)
        :
        this.brandingService.getUserBrand())
        .pipe(map( (res) => {
            var brandColors: Map<string, string>;
            let brand = res.Brand;
            this.themes = res.Themes;
            brandColors = new Map();
            let brandSettingsFlattened = this.flattenObject(brand);
            Object.keys(brandSettingsFlattened).forEach(k => { brandColors.set(k, brandSettingsFlattened[k]); });
            return brandColors;
        }));
    }

    public searchBrand(term:string):Observable<BrandKeySearchResult[]>{
        return this.brandingService.searchBrands(term);
    }

    public getBrandColor(color: BrandColors): string {
        return this.brandColors.get(color);
    }

    public getColorGradient(hex: string, lum: number) {
        // validate hex string
        hex = String(hex).replace(/[^0-9a-f]/gi, '');
        if (hex.length < 6) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        lum = lum || 0;

        // convert to decimal and change luminosity
        let rgb = "#";
        let c;
        let i;
        for (i = 0; i < 3; i++) {
            c = parseInt(hex.substr(i * 2, 2), 16);
            c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
            rgb += (`00${c}`).substr(c.length);
        }
        return rgb;
    }
    public getColorSetFromBrand(brandColor: BrandColors, num) {
        return this.getColourSet(this.getBrandColor(brandColor), num);
    }

    public getColourSet(colour: string, num: number) {
        const colours = [], step = 1 / num;
        let loop = -Math.floor(num / 2);
        for (let i = 0; i < num; i++) {
            colours.push(this.getColorGradient(colour, step * loop));
            loop++;
        }
        return colours;
    }

    public getColorRangeFromBrand(brandColor: BrandColors, length) {
        return this.getColourRange(this.getBrandColor(brandColor), length);
    }
    public getColourRange(hex, length) {
        let colours = [];

        let rgb = this.hexToRgbArray(hex);
        let hsv = this.rgbToHsv(rgb[0], rgb[1], rgb[2]);

        let variations = this.getColourVariations(hsv[1], hsv[2]);

        rgb = this.hsvToRgb(hsv[0], variations[0][0], variations[0][1]);
        let firstVariation = this.rgbToHex(rgb);

        rgb = this.hsvToRgb(hsv[0], variations[1][0], variations[1][1]);
        let secondVariation = this.rgbToHex(rgb);

        colours.push(hex);
        colours.push(firstVariation);
        colours.push(secondVariation);

        if (length > 3) {
            let numberOfGreys = length - 3;
            let greyStep = 170 / numberOfGreys;
            for (let x = numberOfGreys; x >= 1; x--) {
                let hexValue = Math.round((x * greyStep)).toString(16);
                colours.push('#' + hexValue + hexValue + hexValue);
            }
        }
        return colours;
    }

    private getColourVariations(saturation, value) {
        let middleOf = {
            areaOne: [0.5, 0.9],
            areaTwo: [0.7, 0.9],
            areaThree: [0.9, 0.9],
            areaFour: [0.5, 0.7],
            areaFive: [0.7, 0.7],
            areaSix: [0.9, 0.7],
            areaSeven: [0.5, 0.5],
            areaEight: [0.7, 0.5],
            areaNine: [0.7, 0.5]
        };

        // area 1
        if (saturation >= 0.40 && saturation < 0.60 && value >= 0.80) {
            return [middleOf.areaThree, middleOf.areaNine];
        } else if (saturation >= 0.60 && saturation < 0.80 && value >= 0.80) {
            return [middleOf.areaSeven, middleOf.areaNine];
        } else if (saturation >= 0.80 && value >= 0.80) {
            return [middleOf.areaOne, middleOf.areaNine];
        } else if (saturation >= 0.40 && saturation < 0.60 && value >= 0.60 && value < 0.80) {
            return [middleOf.areaThree, middleOf.areaNine];
        } else if (saturation >= 0.60 && saturation < 0.80 && value >= 0.60 && value < 0.80) {
            return [middleOf.areaOne, middleOf.areaNine];
        } else if (saturation >= 0.80 && value >= 0.60 && value < 0.80) {
            return [middleOf.areaOne, middleOf.areaSeven];
        } else if (saturation >= 0.40 && saturation < 0.60 && value >= 0.40 && value < 0.60) {
            return [middleOf.areaOne, middleOf.areaNine];
        } else if (saturation >= 0.60 && saturation < 0.80 && value >= 0.40 && value < 0.60) {
            return [middleOf.areaOne, middleOf.areaThree];
        } else if (saturation >= 0.80 && value >= 0.40 && value < 0.60) {
            return [middleOf.areaThree, middleOf.areaSeven];
        }
        return [middleOf.areaTwo, middleOf.areaSix];
    }

    private hexToRgbArray(hex) {
        let c = hex.substring(1); 	 // strip #
        let rgb = parseInt(c, 16);   // convert rrggbb to decimal
        let r = (rgb >> 16) & 0xff;  // extract red
        let g = (rgb >> 8) & 0xff;  // extract green
        let b = (rgb >> 0) & 0xff;  // extract blue
        let arr = [r, g, b];
        return arr;
    }

    public hexToRgb(hex) {
        let arr = this.hexToRgbArray(hex);
        return `rgb(${arr[0]}, ${arr[1]}, ${arr[2]})`;
    }

    public hexToRgba(hex, alpha) {
        let arr = this.hexToRgbArray(hex);
        return `rgba(${arr[0]}, ${arr[1]}, ${arr[2]}, ${alpha})`;
    }

    private rgbToHex(rgb) {
        let r = Math.round(rgb[0]).toString(16);
        r = ("00" + r).substr(r.length);

        let g = Math.round(rgb[1]).toString(16);
        g = ("00" + g).substr(g.length);

        let b = Math.round(rgb[2]).toString(16);
        b = ("00" + b).substr(b.length);

        return '#' + r + g + b;
    }

    /**
     * Converts an RGB color value to HSV. Conversion formula
     * adapted from http://en.wikipedia.org/wiki/HSV_color_space.
     * Assumes r, g, and b are contained in the set [0, 255] and
     * returns h, s, and v in the set [0, 1].
     *
     * @param   Number  r       The red color value
     * @param   Number  g       The green color value
     * @param   Number  b       The blue color value
     * @return  Array           The HSV representation
     */
    private rgbToHsv(r, g, b) {
        r = r / 255, g = g / 255, b = b / 255;
        let max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, v = max;

        let d = max - min;
        s = max === 0 ? 0 : d / max;

        if (max === min) {
            h = 0; // achromatic
        } else {
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }

        return [h, s, v];
    }

    /**
     * Converts an HSV color value to RGB. Conversion formula
     * adapted from http://en.wikipedia.org/wiki/HSV_color_space.
     * Assumes h, s, and v are contained in the set [0, 1] and
     * returns r, g, and b in the set [0, 255].
     *
     * @param   Number  h       The hue
     * @param   Number  s       The saturation
     * @param   Number  v       The value
     * @return  Array           The RGB representation
     */
    private hsvToRgb(h, s, v) {
        let r, g, b;

        let i = Math.floor(h * 6);
        let f = h * 6 - i;
        let p = v * (1 - s);
        let q = v * (1 - f * s);
        let t = v * (1 - (1 - f) * s);

        switch (i % 6) {
            case 0: r = v, g = t, b = p; break;
            case 1: r = q, g = v, b = p; break;
            case 2: r = p, g = v, b = t; break;
            case 3: r = p, g = q, b = v; break;
            case 4: r = t, g = p, b = v; break;
            case 5: r = v, g = p, b = q; break;
        }

        return [r * 255, g * 255, b * 255];
    }

    private hashString(str) {
        str = str || "";
        str.toUpperCase();
        let p1 = 2654435761, p2 = 1597334677, h1 = 0xdeadbeef | 0, h2 = 0x41c6ce57 | 0;
        for (let i = 0; i < str.length; i++) {
            let ch = str.charCodeAt(i);
            h1 = Math.imul(h1 + ch, p1);
            h2 = Math.imul(h2 + ch, p2);
        }
        h1 = Math.imul(h1 ^ h1 >>> 16, p2), h2 = Math.imul(h2 ^ h2 >>> 15, p1);
        return (h2 & 2097151) * 4294967296 + h1;
    }

    private hslToRgb(h, s, l) {

        let ch = (1 - Math.abs((2 * l) - 1)) * s;
        let hp = h / 60;
        let secondComponent = ch * (1 - Math.abs((hp % 2) - 1));

        hp = Math.floor(hp);
        let r, g, b;

        if (hp === 0) {
            r = ch;
            g = secondComponent;
            b = 0;
        } else if (hp === 1) {
            r = secondComponent;
            g = ch;
            b = 0;
        } else if (hp === 2) {
            r = 0;
            g = ch;
            b = secondComponent;
        } else if (hp === 3) {
            r = 0;
            g = secondComponent;
            b = ch;
        } else if (hp === 4) {
            r = secondComponent;
            g = 0;
            b = ch;
        } else if (hp === 5) {
            r = ch;
            g = 0;
            b = secondComponent;
        }

        let adj = l - (ch / 2);
        return [Math.round((r + adj) * 255), Math.round((g + adj) * 255), Math.round((b + adj) * 255)];
    }

    strToColor(string, sat, lightness) {
        return this.hslToRgb(this.hashString(string) % 360, sat, lightness);
    }

    getUserAvatarColor(seed) {
        if (this.userAvatarTheme != null) {
            let id = Math.floor(this.hashString(seed) % this.userAvatarTheme.length);
            return this.userAvatarTheme[id];
        }
        // default auto generated
        let col = this.strToColor(seed, .3, .5);
        return `rgb(${col[0]},${col[1]},${col[2]})`;
    }

    getThemeColors(chartType: ChartThemes, iterations: number, loopTheme?: boolean): string[] {
        let theme = this.brandColors.get(chartType);
        if (theme == null) {
            return this.getColorSetFromBrand(BrandColors.BrandColor, iterations + 1);
        }
        let colors = this.themes[theme] || this.getColorSetFromBrand(BrandColors.BrandColor, iterations + 1);
        if (colors.length < iterations) {
            if (loopTheme && this.themes[theme] != null) {
                while (colors.length < iterations) {
                    colors = colors.concat(colors);
                }
            } else {
                let additionalColors = this.getColorSetFromBrand(BrandColors.BrandColor, colors.length - iterations);
                return colors.concat(additionalColors);
            }
        }
        return colors;
    }

    private flattenObject(ob: any): any {
        const obj = {};

        for (const property in ob) {
            if (!ob.hasOwnProperty(property)) {
                continue;
            }
            if ((typeof ob[property]) === 'object') {
                const flatObject = this.flattenObject(ob[property]);
                for (const key2 in flatObject) {
                    if (!flatObject.hasOwnProperty(key2)) {
                        continue;
                    }
                    obj[key2] = flatObject[key2];
                }
            } else {
                obj[property] = ob[property];
            }
        }
        return obj;
    }
}

export enum BrandColors {
    BrandColor = "brandColor",
    AccentColor = "accentColor",
    // element colors
    PositiveColor = "positiveColor",
    NegativeColor = "negativeColor",
    ColumnChartLineColor = "columnChartLineColor",
    BenchmarkLineColor = "benchmarkLineColor",
    PrimaryTextColor = "primaryTextColor",
    PrimaryButtonColor = "primaryButtonColor",
    SecondaryTextColor = "secondaryTextColor",

    InvestmentColor = "investmentColor",
    // category colors
    SuperColor = "superColor",
    PropertyColor = "propertyColor",
    CashColor = "cashColor",
    OtherColor = "otherColor",
    LiabilityColor = "liabilityColor",
    InsuranceColor = "insuranceColor",

    // transaction colors
    AdditionsColor = "additionsColor",
    IncomeColor = "incomeColor",
    WithdrawalsColor = "withdrawalsColor",
    ExpensesColor = "expensesColor",
    BuysColor = "buysColor",
    SellsColor = "sellsColor",
}

export enum ChartThemes {
    BarChart = "barChartTheme",
    PieChart = "pieChartTheme",
    FunnelChart = "funnelChartTheme",
    LineChart = "lineChartTheme",
    ColumnChart = "columnChartTheme",
    EditModelChart = "editModelTheme",
    OtherChart = "otherChartTheme",
    UserAvatar = "userAvatarTheme",
    TreemapChart = "treemapTheme",
}

export interface IHsl {
    h: number;
    s: number;
    l: number;
}