import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as momentImported from 'moment';
import { SplashService, Splash, SplashPagedResults, Response, ApplicationContext, Status } from '../api/content-service.module';
 const moment = momentImported;

@Injectable()
export class ContentService {

    constructor(private splashService: SplashService) {
    };

    getSplash(splashId:string): Observable<Splash>{
        return this.splashService.getSplash(splashId);
    }

    getSplashByServiceId(continuationToken:string = null, take:number = 9, term:string = null, status:Status=null): Observable<SplashPagedResults>{
        return this.splashService.getSplashes(
                continuationToken?encodeURIComponent(continuationToken):null,
                take, 
                term,
                status
            
        );
    }

    upsertSplash(splash:Splash): Observable<string>{
        splash.from = this.toDateTimeZoneString(splash.from);
        splash.to = this.toDateTimeZoneString(splash.to);
        return this.splashService.upsertSplash(splash);
    }

    deleteSplash(splashId:string): Observable<boolean>{
        return this.splashService.deleteSplash(splashId);
    }

    publishSplash(splashId:string): Observable<Response>{
        return this.splashService.publishSplash(splashId);
    }

    /*splash page*/
    getSplashes(context:ApplicationContext): Observable<Splash[]>{
        return this.splashService.getContextSplashes(context);
    }

    viewSplash(context:ApplicationContext): Observable<boolean>{
        return this.splashService.viewSplash(context);
    }

    getCachedSplash(context:ApplicationContext, splashId:string): Observable<Splash>{
        return this.splashService.getCachedSplash(context, splashId);
    }

    /*date functions */
    defaultDateFormat =  'DD/MM/YYYY HH:mm';
    readableDateFormat = 'DD MMM YYYY HH:mm';
    timezoneDateFormat = 'DD MMM YYYY HH:mm Z';
    
    toDateStringFlex(value: any): string {
        if (value && value !== '') {
            let momentValue = moment(value, this.defaultDateFormat);
            if (!momentValue.isValid()) {
                momentValue = moment(new Date(value));
            }
            return momentValue.format(this.readableDateFormat);
        }
        return '';
    }

    toDateTimeZoneString(value: any): string {
        if (value && value !== '') {
            let momentValue = moment(value, this.defaultDateFormat);
            if (!momentValue.isValid()) {
                momentValue = moment(new Date(value));
            }
            return momentValue.format(this.timezoneDateFormat);
        }
        return '';
    }
}

