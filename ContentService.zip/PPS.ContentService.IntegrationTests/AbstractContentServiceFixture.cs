// using NUnit.Framework;
// using PPS.ContentService.Contracts;
// using PPS.ContentService.Data.UnitTests;
// using System.Collections.Generic;
// using System.Threading.Tasks;

// namespace PPS.ContentService.IntegrationTests
// {
//     public abstract class AbstractContentServiceFixture : BaseIntegrationFixture
//     {
//         [OneTimeTearDown]
//         public async Task OneTimeTearDown()
//         {
//             await _cosmosClient.CleanUp();
//         }

//         [SetUp]
//         public async Task SetUp()
//         {
//             await _cosmosClient.CleanUp();
//             var splash = GetTestSplash();
//             await _splashRepository.UpsertSplash(splash.CreatedBy, splash);
//         }

//     }
// }