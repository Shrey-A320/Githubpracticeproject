// using NUnit.Framework;
// using PPS.ContentService.Contracts;
// using PPS.ContentService.Data.UnitTests.Repositories;
// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Net;
// using System.Net.Http;
// using System.Text;
// using System.Threading.Tasks;

// namespace PPS.ContentService.IntegrationTests
// {
//     [TestFixture]
//     public class DeleteContentServiceFixture : AbstractContentServiceFixture
//     {

//         [Test]
//         public async Task TestDeleteContentService()
//         {
//             var testDocs = GetTestSplash();

//             await _splashRepository.UpsertSplash(testDocs.CreatedBy, testDocs);

//             var response = await SendTestDeleteRequest(testDocs.Id);

//             Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
//             Assert.IsNull(await _splashRepository.GetSplash(testDocs.Id));
//         }


//         private async Task<HttpResponseMessage> SendTestDeleteRequest(string id)
//         {
//             var request = new HttpRequestMessage(HttpMethod.Delete,$"splash/{id}");
            
//             return await _testClient.SendAsync(request);
//         }
//     }
// }