using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NUnit.Framework;
using PPS.Authentication.Web.AppToken;
using PPS.ContentService.Core;
using PPS.ContentService.Data;
using PPS.ContentService.Data.UnitTests;
using PPS.ContentService.Web.Filters;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using TokenValidatedContext = PPS.Authentication.Web.AppToken.TokenValidatedContext;

namespace PPS.ContentService.IntegrationTests.Helpers
{
    public static class TestClientHelper
    {
        public static HttpClient GetTestClient()
        {
            var testServer = new TestServer(new WebHostBuilder().UseStartup<TestStartup>());
            return testServer.CreateClient();
        }
    }

    public class TestStartup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.Configure<ApiBehaviorOptions>(options =>
            {
                // Automatic model validation would skip RouteTemplateFilter,
                // so suppressed here and added back as ValidateModelAttribute
                options.SuppressModelStateInvalidFilter = true;
            });
            // Bypass authentication for integration tests
            services.AddAuthentication().AddScheme<PpsTokenOptions, PpsTokenAuthenticationHandler>(TokenHelper.SchemeName, o => { });

            services.UseContentServiceCore(opts =>
            {
                opts.UserServiceUrl = "localhost:8080";
                opts.AppToken = "token";
                opts.CosmosSettings = new CosmosSettings() {
                    Url = TestHelper.TestSettings.CosmosSettings.Url,
                    ConnectionKey = TestHelper.TestSettings.CosmosSettings.ConnectionKey,
                    DbName = TestHelper.TestSettings.CosmosSettings.DbName,
                    MaxRu = TestHelper.TestSettings.CosmosSettings.MaxRu,
                    MaxRetryAttemptsOnRateLimitedRequests = TestHelper.TestSettings.CosmosSettings.MaxRetryAttemptsOnRateLimitedRequests,
                    MaxRetryWaitTimeMinuteOnRateLimitedRequests = TestHelper.TestSettings.CosmosSettings.MaxRetryWaitTimeMinuteOnRateLimitedRequests,
                };
            }); ; ;

            services.AddTransient<ValidateModelAttribute>();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment _)
        {
            app.UseRouting();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseAuthorization();
            app.UseEndpoints(c => c.MapControllers());
        }
    }

    public class PpsTokenAuthenticationHandler : AuthenticationHandler<PpsTokenOptions>
    {
        public PpsTokenAuthenticationHandler(
            IOptionsMonitor<PpsTokenOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock) : base(options, logger, encoder, clock)
        {
        }

        protected async override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var app = new TokenApplication
            {
                Id = "test",
                Name = "test",
                Permissions = new List<string> { "Read", "Write" },
            };

            var ppal = GetPrincipal(app);

            var valCtx = new TokenValidatedContext(Context, Scheme, Options)
            {
                Principal = ppal,
                Application = app
            };

            valCtx.Success();

            return valCtx.Result;
        }

        private ClaimsPrincipal GetPrincipal(TokenApplication app)
        {
            var identity = new ClaimsIdentity(new[] {
                new Claim(ClaimTypes.NameIdentifier, app.Id),
                new Claim(ClaimTypes.Name, app.Name),
            }, Scheme.Name);

            foreach (var permission in app.Permissions)
            {
                identity.AddClaim(new Claim(ClaimTypes.Role, TokenHelper.RolePrefix + permission));
            }

            return new ClaimsPrincipal(identity);
        }
    }
}