// using NUnit.Framework;
// using PPS.ContentService.Contracts;
// using PPS.ContentService.Data.UnitTests.Repositories;
// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Net;
// using System.Threading.Tasks;

// namespace PPS.ContentService.IntegrationTests
// {
//     [TestFixture]
//     public class AddContentServiceFixture : AbstractContentServiceFixture
//     {
//         [Test]
//         public async Task TestAddContentService()
//         {
//             var expected = GetTestSplash();

//             var response = await _testClient.PostAsync($"splash", ConstructJsonRequestBody(expected));

//             Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
//         }

//     }
// }