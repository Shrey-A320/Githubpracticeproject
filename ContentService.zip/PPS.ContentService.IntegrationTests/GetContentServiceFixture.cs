// using Newtonsoft.Json;
// using NUnit.Framework;
// using PPS.ContentService.Contracts;
// using PPS.ContentService.Data.UnitTests.Repositories;
// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Net;
// using System.Threading.Tasks;

// namespace PPS.ContentService.IntegrationTests
// {
//     [TestFixture]
//     public class GetContentServiceFixture : AbstractContentServiceFixture
//     {
        
//         [Test]
//         public async Task TestGetContentService()
//         {
//             var testDoc = GetTestSplash();

//             await _splashRepository.UpsertSplash(testDoc.CreatedBy, testDoc);

//             var response = await _testClient.GetAsync($"splash/{testDoc.Id}");

//             Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

//             var expectedResponseContent = JsonConvert.SerializeObject(_mapper.Map<Splash>(testDoc)).ToLower();
//             var responseContent = (await response.Content.ReadAsStringAsync()).ToLower();
//             Assert.AreEqual(expectedResponseContent, responseContent);
//         }


//     }

            
// }