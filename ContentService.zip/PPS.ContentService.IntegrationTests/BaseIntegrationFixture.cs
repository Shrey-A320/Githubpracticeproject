// using AutoMapper;
// using Microsoft.Azure.Cosmos;
// using Newtonsoft.Json;
// using NUnit.Framework;
// using PPS.ContentService.Contracts;
// using PPS.ContentService.Core.Mapper;
// using PPS.ContentService.Data;
// using PPS.ContentService.Data.Repositories;
// using PPS.ContentService.Data.UnitTests;
// using PPS.ContentService.Data.UnitTests.Repositories;
// using PPS.ContentService.IntegrationTests.Helpers;
// using System;
// using System.Net.Http;
// using System.Net.Http.Headers;

// namespace PPS.ContentService.IntegrationTests
// {
//     public class BaseIntegrationFixture
//     {
//         protected HttpClient _testClient;
//         protected CosmosClient _cosmosClient;
//         protected ISplashRepository _splashRepository;
//         protected IMapper _mapper;

//         [OneTimeSetUp]
//         public void OneTimeSetUp()
//         {
//             _testClient = TestClientHelper.GetTestClient();
//             _cosmosClient = TestHelper.GetCosmosClient();
//             _splashRepository = new SplashRepository(_cosmosClient, new MemoryStreamManager());
//             _mapper = new MapperConfiguration(cfg =>
//             {
//                 cfg.AddMaps(typeof(ContentServiceProfile).Assembly);
//             }).CreateMapper();
//         }

//         protected StringContent ConstructJsonRequestBody(object bodyObject)
//         {
//             var body = new StringContent(JsonConvert.SerializeObject(bodyObject));
//             body.Headers.ContentType = new MediaTypeHeaderValue("application/json");
//             body.Headers.Add("userID", SplashServiceTestProvider.CREATEDBY);
//             body.Headers.Add("serviceID", SplashServiceTestProvider.PARTITION);

//             return body;
//         }

//         protected SplashDocument GetTestSplash() => new SplashDocument
//         {
//             ServiceId = SplashServiceTestProvider.PARTITION,
//             Id = SplashServiceTestProvider.PARTITION + "1",
//             CreatedBy = SplashServiceTestProvider.CREATEDBY,
//             Updates = Array.Empty<Update>(),
//             Pds = Array.Empty<string>(),
//             UserLevels = Array.Empty<UserLevelContext>(),
//             Applications = Array.Empty<ApplicationContext>(),
//             Regions = Array.Empty<RegionContext>(),
//             Tags = Array.Empty<string>()
//         };
//     }
// }