using NUnit.Framework;
using PPS.ContentService.Contracts;
using RestSharp;
using System;
using System.Collections.Generic;

namespace PPS.ContentService.Client.UnitTests
{
    [TestFixture]
    public class ContentServiceClientFixture
    {
        private readonly string _testUrl = "http://localhost";
        private readonly string _testToken = "some token";

        private ContentServiceClient _client;

        [SetUp]
        public void SetUp()
        {
            _client = new ContentServiceClient(_testUrl, _testToken);
        }

        [Test]
        public void TestGetContentService()
        {
            var id = "01";
            var apiRequest = _client.GetSplashById(id);

            Assert.AreEqual(Method.GET, apiRequest.Method);
            Assert.AreEqual(
                @$"{_testUrl}/splash/{id}"
                    .Replace("\r\n", "")
                    .Replace(" ", ""),
                apiRequest.Url.AbsoluteUri);
        }


        [Test]
        public void TestGetContentServices()
        {
            var token = "TOKEN";
            var take = 10;
            var term = "term";
            var status = Status.Draft;
            var apiRequest = _client.GetSplashes(token, take, term, status);

            Assert.AreEqual(Method.GET, apiRequest.Method);
            Assert.AreEqual(
                @$"{_testUrl}/splash?continuationToken={token}&take={take}&term={term}&status={Status.Draft}"
                    .Replace("\r\n", "")
                    .Replace(" ", ""),
                apiRequest.Url.AbsoluteUri);
        }

        [Test]
        public void TestAddContentService()
        {
            var item = new Splash();
            var apiRequest = _client.UpsertSplash(item);

            Assert.AreEqual(Method.POST, apiRequest.Method);
            Assert.AreEqual($"{_testUrl}/splash", apiRequest.Url.AbsoluteUri);
        }

        [Test]
        public void TestDeleteContentService()
        {

            var id = "01";
            var apiRequest = _client.DeleteSplash(id);

            Assert.AreEqual(Method.DELETE, apiRequest.Method);
            Assert.AreEqual(
                @$"{_testUrl}/splash/{id}"
                    .Replace("\r\n", "")
                    .Replace(" ", ""),
                apiRequest.Url.AbsoluteUri);
        }

        [Test]
        public void TestGetCachedContentService()
        {
            var splashId = "01";
            var context = ApplicationContext.AdviserPortal;
            var apiRequest = _client.GetCachedSplash(context, splashId);

            Assert.AreEqual(Method.GET, apiRequest.Method);
            Assert.AreEqual(
                @$"{_testUrl}/splash/get/{context}/{splashId}"
                    .Replace("\r\n", "")
                    .Replace(" ", ""),
                apiRequest.Url.AbsoluteUri);
        }

    }
}