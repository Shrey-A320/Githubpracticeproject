﻿using PPS.ContentService.Contracts.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PPS.ContentService.Contracts
{
    public class SplashDocument : Splash
    {
        public string id { get => Id; }
        public string partition { get => Region; }
    }
    public class Splash
    {
        public string Id { get; set; }
        public string CreatedBy { get; set; }
        public string ServiceId { get; set; }
        public string Region { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string Content { get; set; }
        public DateTimeOffset? Created { get; set; }
        public DateTimeOffset? Published { get; set; }
        public Update[] Updates { get; set; }
        public Status Status { get; set; }
        /* targeting */
        public IEnumerable<string> Pds { get; set; }
        [CantBeEmpty(ErrorMessage = "A user level target context must be provided")]
        public IEnumerable<UserLevelContext> UserLevels { get; set; }
        [CantBeEmpty(ErrorMessage = "An application target context must be provided")]
        public IEnumerable<ApplicationContext> Applications { get; set; }
        [CantBeEmpty(ErrorMessage = "An region target context must be provided")]
        public IEnumerable<RegionContext> Regions { get; set; }
        public IEnumerable<string> Tags { get; set; }
        [Required(ErrorMessage = "A start date must be provided."), DateMustBeAfter(errorMessage: "Start date must be after {1:dd MMM yyyy}.")]
        public DateTimeOffset? From { get; set; }
        [Required(ErrorMessage = "A finish date must be provided."), DateMustBeAfter(afterDate:"From", errorMessage: "Finish date must be after {1:dd MMM yyyy}.")]
        public DateTimeOffset? To { get; set; }
        public ServiceAccountType ServiceType { get; set; }
        public IEnumerable<string> ExcludedServices { get; set; }
        public string BrandOverride { get; set; }


    }

    public class Update
    {
        public string UpdatedBy { get; set; }
        public DateTimeOffset? Updated { get; set; }
    }

    public enum Status
    {
        Draft,
        Published,
        Live,
        Expired
    }

    public enum ApplicationContext
    {
        HAL,
        Applications,
        InvestorPortal,
        AdviserPortal,
    }

    public enum UserLevelContext
    {
        Investor = 1,
        Adviser = 2,
        Administrator = 3,
        ThirdParty = 4,
        ModelManager = 5,
        Manager = 6
    }

    public enum RegionContext
    {
        AU,
        UK,
        PLUM
    }

    public enum ServiceAccountType
    {
        Hybrid = 0,
        Vma = 1,
        Sma = 2,
        SmaOnly = 3,
        VmaOnly = 4,
    }

    

}
