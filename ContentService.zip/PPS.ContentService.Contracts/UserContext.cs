﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PPS.ContentService.Contracts
{
    public class UserContext
    {
        public string UserType { get; set; }
        public string ServiceId { get; set; }
        public RegionContext Region { get; set; }
        public DateTime LastViewed { get; set; }
        public IEnumerable<string> Applications { get; set; }
    }
}
