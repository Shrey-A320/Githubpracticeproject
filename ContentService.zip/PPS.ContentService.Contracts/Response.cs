﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PPS.ContentService.Contracts
{
    public class Response
    {
        public bool Success { get; set; }
        public Dictionary<string, string> Messages { get; set; }
    }
}
