﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PPS.ContentService.Contracts
{
    public class Service
    {

        public string Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public string PageTitle { get; set; }
        public string BrandKey { get; set; }
        public ServiceAccountType ServiceType { get; set; }
        public IEnumerable<string> ChildServices { get; set; }

    }
}
