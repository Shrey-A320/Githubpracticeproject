﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;

namespace PPS.ContentService.Contracts.Helpers
{
    public sealed class DateMustBeAfterAttribute : ValidationAttribute
    {
        
        private readonly object _typeId = new object();

        public DateMustBeAfterAttribute(string errorMessage = "'{0}' must be after '{1}'.", string afterDate = null)
            : base(errorMessage)
        {
            AfterDate = afterDate;
        }

        public string AfterDate
        {
            get;
            private set;
        }

        public override bool IsValid(object value)
        {
            return base.IsValid(value);
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTimeOffset? afterDate = DateTime.Now;
            if (!string.IsNullOrEmpty(AfterDate))
            {
                var property = validationContext.ObjectType.GetProperty(AfterDate);

                if (property != null && (property.PropertyType == typeof(DateTimeOffset) || property.PropertyType == typeof(DateTimeOffset?)))
                    afterDate = (DateTimeOffset?)property.GetValue(validationContext.ObjectInstance, null);
            }

            if (value !=null && afterDate.HasValue && ((DateTimeOffset)value) < afterDate.Value)
                return new ValidationResult(String.Format(CultureInfo.CurrentUICulture, ErrorMessageString, validationContext.DisplayName, afterDate), new string[1] { validationContext.DisplayName });

            return null;
        }
        

    }
}
