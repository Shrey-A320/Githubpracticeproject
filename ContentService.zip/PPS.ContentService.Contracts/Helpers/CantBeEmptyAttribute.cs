﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;

namespace PPS.ContentService.Contracts.Helpers
{
    public sealed class CantBeEmptyAttribute : ValidationAttribute
    {
        
        private readonly object _typeId = new object();

        public CantBeEmptyAttribute(string errorMessage = "'{0}' can't be empty.")
            : base(errorMessage)
        {}

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
           if (value is IList && (value==null || ((IList)value).Count==0))
                return new ValidationResult(String.Format(CultureInfo.CurrentUICulture, ErrorMessageString, validationContext.DisplayName), new string[1] { validationContext.DisplayName });

            return null;
        }
        

    }
}
