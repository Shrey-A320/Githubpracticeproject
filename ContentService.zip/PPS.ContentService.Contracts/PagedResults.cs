﻿using System.Collections.Generic;

namespace PPS.ContentService.Contracts
{
    public class PagedResults<T>
    {
        public IEnumerable<T> Items { get; set; }
        public string ContinuationToken { get; set; }
    }
}
