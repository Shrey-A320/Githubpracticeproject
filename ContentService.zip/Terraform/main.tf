provider "azurerm" {
  features {}
  subscription_id = "e9913b8f-f534-406d-a018-d4b1570f220e"
}


module "resource_group" {
  source              = "./modules/resource_group"
  resource_group_name = var.resource_group_name
  location            = var.location
}

module "log_analytics" {
  source              = "./modules/log_analytics"
  resource_group_name = var.resource_group_name
  location            = var.location
  law_name            = var.law_name
  depends_on          = [module.resource_group]
}

module "app_insights" {
  source                 = "./modules/app_insights"
  resource_group_name    = var.resource_group_name
  location               = var.location
  app_insights_name      = var.app_insights_name
  log_analytics_workspace_id = module.log_analytics.log_analytics_id
  depends_on          = [module.log_analytics]
}

module "cosmos_db" {
  source              = "./modules/cosmos_db"
  resource_group_name = var.resource_group_name
  location            = var.location
  cosmosdb_name       = var.cosmosdb_name
  database_name       = var.database_name
  container_name      = var.container_name
  depends_on          = [module.app_insights]
}

data "azurerm_subnet" "web" {
  name                 = var.subnet_name              
  virtual_network_name = var.vnet_name                
  resource_group_name  = var.vnet_resource_group_name 
}


module "app_service" {
  source                       = "./modules/app_service"
  app_service_plan_name        = var.app_service_plan_name
  app_service_name             = var.app_service_name
  resource_group_name          = var.resource_group_name
  location                     = var.location
  app_insights_key             = module.app_insights.instrumentation_key
  cosmosdb_connection_string   = module.cosmos_db.connection_string
  
  subnet_id = data.azurerm_subnet.web.id

  depends_on          = [module.cosmos_db]
}
