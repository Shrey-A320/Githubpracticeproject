location = "UK South"
resource_group_name = "rg-contentservice-tf-qa"

create_resource_group = true
create_law = true
law_name = "law-contentservice-tf-qa-uks"

create_app_insights = true
app_insights_name = "appi-contentservice-tf-qa"

create_cosmosdb = true
cosmosdb_name = "cosmos-contentservice-tf-qa-uks"

create_app_service = true
app_service_plan_name = "asp-contentservice-tf-qa-uks"
app_service_name = "app-contentservice-tf-qa-uks"

vnet_resource_group_name  = "ogp-test"
vnet_name = "ogp-uks-vnet-test"
subnet_name = "WebApp"
database_name= "mydatabase"
container_name = "mycontainer"