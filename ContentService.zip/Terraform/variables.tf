variable "location" {}
variable "resource_group_name" {}
variable "create_resource_group" { default = true }

variable "create_law" { default = true }
variable "law_name" {}

variable "create_app_insights" { default = true }
variable "app_insights_name" {}

variable "create_cosmosdb" { default = true }
variable "cosmosdb_name" {}
variable "database_name" {
  default = "mydatabase"
}

variable "container_name" {
  default = "mycontainer"
}

variable "create_app_service" { default = true }
variable "app_service_plan_name" {}
variable "app_service_name" {}

variable "subnet_name" {}
variable "vnet_name" {}
variable "vnet_resource_group_name" {}
