output "app_service_url" {
  value = module.app_service.app_service_default_hostname
}
