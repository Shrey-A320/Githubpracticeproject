output "instrumentation_key" {
  value = azurerm_application_insights.appinsights.instrumentation_key
  #condition = length(azurerm_application_insights.appinsights) > 0
}
