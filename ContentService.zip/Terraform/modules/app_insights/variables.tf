variable "create_app_insights" {
  type    = bool
  default = true
}

variable "app_insights_name" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "log_analytics_workspace_id" {
  type = string
}
