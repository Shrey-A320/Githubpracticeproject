resource "azurerm_cosmosdb_account" "cosmos" {
  name                = var.cosmosdb_name
  location            = var.location
  resource_group_name = var.resource_group_name
  offer_type          = "Standard"
  kind                = "GlobalDocumentDB"

  consistency_policy {
    consistency_level = "Session"
  }

  geo_location {
    location          = var.location
    failover_priority = 0
  }
  capabilities {
    name = "EnableServerless"
  }
  tags = {
    ENVIRONMENT = "qa"
    SERVICEID   = "ts01544"
    Application = "shared"
    Product     = "mwpint-shared"
    System      = "shared-communication"
    Service     = "content-service"
  }
}

resource "azurerm_cosmosdb_sql_database" "cosmosdb" {
  name                = var.database_name
  resource_group_name = var.resource_group_name
  account_name        = var.cosmosdb_name

  depends_on          = [azurerm_cosmosdb_account.cosmos]
}

resource "azurerm_cosmosdb_sql_container" "cosmossqlcontainer" {
  name                = var.container_name
  resource_group_name = var.resource_group_name
  account_name        = var.cosmosdb_name
  database_name       = var.database_name
  partition_key_paths  = ["/partitionKey"]
  depends_on          = [azurerm_cosmosdb_sql_database.cosmosdb]
}