variable "create_cosmosdb" {
  type    = bool
  default = true
}

variable "cosmosdb_name" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "database_name" {
    type = string
}
variable "container_name" {
    type = string
}
