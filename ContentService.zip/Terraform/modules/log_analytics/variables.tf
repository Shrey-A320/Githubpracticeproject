variable "create_law" {
  type    = bool
  default = true
}

variable "law_name" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}
