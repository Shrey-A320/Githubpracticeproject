output "log_analytics_id" {
  value = azurerm_log_analytics_workspace.law.id
  #condition = length(azurerm_log_analytics_workspace.law) > 0
}

output "log_analytics_workspace_id" {
  value = azurerm_log_analytics_workspace.law.workspace_id
  #condition = length(azurerm_log_analytics_workspace.law) > 0
}
