variable "create_app_service" {
  type    = bool
  default = true
}

variable "app_service_plan_name" {
  type = string
}

variable "app_service_name" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}

variable "app_insights_key" {
  type = string
}

variable "cosmosdb_connection_string" {
  type = string
}

variable "subnet_id" {
  type = string
}
