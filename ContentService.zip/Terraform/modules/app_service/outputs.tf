output "app_service_default_hostname" {
  value = azurerm_app_service.webapp.default_site_hostname
}
