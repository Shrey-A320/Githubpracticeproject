resource "azurerm_app_service_plan" "app_serviceplan" {
  name                = var.app_service_plan_name
  location            = var.location
  resource_group_name = var.resource_group_name
  kind                = "Windows"

  sku {
    tier = "Basic"
    size = "B1"
  }
  tags = {
    ENVIRONMENT = "qa"
    SERVICEID   = "ts01544"
    Application = "shared"
    Product     = "mwpint-shared"
    System      = "shared-communication"
    Service     = "content-service"
  }
}

resource "azurerm_app_service" "webapp" {
  name                = var.app_service_name
  location            = var.location
  resource_group_name = var.resource_group_name
  app_service_plan_id = azurerm_app_service_plan.app_serviceplan.id

  site_config {
    dotnet_framework_version = "v6.0"
  }
  tags = {
    ENVIRONMENT = "qa"
    SERVICEID   = "ts01544"
    Application = "shared"
    Product     = "mwpint-shared"
    System      = "shared-communication"
    Service     = "content-service"
  }

  app_settings = {
    "APPINSIGHTS_INSTRUMENTATIONKEY" = var.app_insights_key
    "CosmosDbConnection"             = var.cosmosdb_connection_string
  }
  depends_on = [azurerm_app_service_plan.app_serviceplan] 
}
