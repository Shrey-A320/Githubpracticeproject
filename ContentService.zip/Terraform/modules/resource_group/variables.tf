variable "create_resource" {
  type    = bool
  default = true
}

variable "resource_group_name" {
  type = string
}

variable "location" {
  type = string
}
