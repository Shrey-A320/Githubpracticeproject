resource "azurerm_resource_group" "rg" {
  count    = var.create_resource ? 1 : 0
  name     = var.resource_group_name
  location = var.location
  tags = {
    ENVIRONMENT = "qa"
    SERVICEID   = "ts01544"
    Application = "shared"
    Product     = "mwpint-shared"
    System      = "shared-communication"
    Service     = "content-service"
  }
}
