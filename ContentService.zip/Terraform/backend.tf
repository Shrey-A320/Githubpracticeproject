terraform {
  backend "azurerm" {
    resource_group_name  = "ogp-test"
    storage_account_name = "aazuredevopsmigrat1510"
    container_name       = "tfstate"
    key                  = "infra.terraform.tfstate"
  }
}
