﻿using System;
using System.Threading.Tasks;
using PPS.UserService.Client;
using PPS.ContentService.Core.Helpers;
using Microsoft.Extensions.Options;
using PPS.Common.Contracts;
using PPS.ContentService.Contracts;
using AutoMapper;

namespace PPS.ContentService.Core
{
    public class UserContextService : IUserContextService
    {
        private readonly ContentServiceOptions _options;
        private readonly IUserService _userService;
        private readonly DataCache<int, UserContext> _userContextCache;
        private readonly DataCache<string, Service> _serviceCache;
        private readonly IMapper _mapper; 

        public UserContextService(IUserService userService, IOptions<ContentServiceOptions> options, IMapper mapper)
        {
            _options = options.Value;
            _userService = userService;
            _mapper = mapper;
            _userContextCache = new DataCache<int, UserContext>((id)=> GetUserContextFromSource(id));
            _serviceCache = new DataCache<string, Service>((id) => GetServiceFromSource(id), new TimeSpan(0, 0, 30, 0), new TimeSpan(0, 0, 30, 0));

        }

        public UserContext GetUserContext(string userId)
        {
            var user = _userContextCache.GetById(int.Parse(userId));
            return user;
            
        }

        public Service GetService(string serviceId)
            => _serviceCache.GetById(serviceId);

        public async Task<DateTime> GetSplashLastChecked(string userId, string key)
        {
            return await GetLastChecked(userId, key);
        }
        
        public async Task UpdateLastChecked(string userId, string key){
            if(!string.IsNullOrEmpty(key))
                await _userService.UpdateUserSettings(int.Parse(userId), _options.ApplicationName, key.ToLower(), DateTimeOffset.Now.ToUtc().ToConfigurationFormattedDate()).ExecuteAndProcess();
        }


        private async Task<DateTime> GetLastChecked(string userId, string key, bool update = false)
        {
            var defaultDate = TimeZoneInfo.ConvertTimeToUtc(DateTime.Now).AddDays(-_options.DefaultStartDateDaysPrior);
            if(string.IsNullOrEmpty(key))
                return defaultDate;
            key = key.ToLower();
            try
            {
                var settings = (await _userService.GetUserSettings(int.Parse(userId), _options.ApplicationName).ExecuteAndProcess());
                var lastCheckedDate = settings != null && settings.ContainsKey(key) ? settings[key]?.FromConfigurationFormattedDate() : null;
                if (update)
                    await UpdateLastChecked(userId, key);
                return lastCheckedDate ?? defaultDate;
            }
            catch (Exception e)
            {
                return defaultDate;
            }
        }

        public async Task<UserContext> GetUserContextFromSource(int userId)
        {
            var user = await _userService.GetUser(userId).ExecuteAndProcess();
            if(user==null)
                return null;
            var serviceId = user.ServiceId;
            RegionContext region = RegionContext.AU;

            switch (IdConverter.GetPrefix(serviceId))
            {
                case IdPrefix.Uk:
                    region = RegionContext.UK;
                    break;
                case IdPrefix.Pl:
                    region = RegionContext.PLUM;
                    break;
            }

            var UserType = GetUserType(user);

            return new UserContext()
            {
                ServiceId = user.ServiceId,
                UserType = UserType,
                Region = region,
                //Applications = (await _authClient.Users.GetApplications(userId).ExecuteAndProcess()).Where(app => app != null && !string.IsNullOrEmpty(app.Name)).Select(app => app.Name.ToLower().Replace(" ", "")).Where(t => !string.IsNullOrEmpty(t))
            };
        }

        public async Task<Service> GetServiceFromSource(string serviceId)
        {
            var service = _mapper.Map<Service>(await _userService.GetService(serviceId)
                .ExecuteAndProcess());
            service.ChildServices = await _userService.GetChildServices(serviceId)
                .ExecuteAndProcess();
            return service;
            
        }


        private string GetUserType(PPS.UserService.Contract.User user){
            PPS.UserService.Contract.UserType type = user.UserLevel > 12 ? 
                PPS.UserService.Contract.UserType.Administrator : 
                    user.UserLevel > 1 ? PPS.UserService.Contract.UserType.Adviser :
                    PPS.UserService.Contract.UserType.Investor;
            if(user.Type == PPS.UserService.Contract.UserType.ModelManager)
                type = PPS.UserService.Contract.UserType.ModelManager;
            return Enum.GetName(typeof(UserService.Contract.UserType), type);
        }

        public void ClearCache()
        {
            _userContextCache.Clear();
        }
    }
}
