﻿using AutoMapper;
using PPS.ContentService.Contracts;
using System;

namespace PPS.ContentService.Core.Mapper
{
    public class ContentServiceProfile : Profile
    {
        public ContentServiceProfile() : base(nameof(ContentServiceProfile))
        {
            CreateMap<SplashDocument, Splash>()
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => MapStatus(src)));

            Func<DateTimeOffset?, DateTimeOffset?> toUtc = (date) => date.HasValue ? (DateTimeOffset?)date.Value.UtcDateTime : null;
            CreateMap<Splash, SplashDocument>()
                .ForMember(dest => dest.From, opt => opt.MapFrom(src => toUtc(src.From)))
                .ForMember(dest => dest.To, opt => opt.MapFrom(src => toUtc(src.To)))
                .ForMember(dest => dest.Published, opt => opt.MapFrom(src => toUtc(src.Published)));

            CreateMap<PagedResults<SplashDocument>, PagedResults<Splash>>()
                //.ForMember(dest => dest.Items, opt => opt.ConvertUsing< opt.MapFrom(src=> src.Items.Select(i=> ) ))
                .ReverseMap();

            CreateMap<UserService.Contract.ServiceAccountType, ServiceAccountType>()
                .ReverseMap();

            CreateMap<UserService.Contract.Service, Service>()
                .ForMember(s=>s.ChildServices, o=> o.Ignore())
                .ReverseMap();
        }

        private Status MapStatus(Splash src)
        {
            return (src.Status == Status.Published && DateTimeOffset.Now >= src.From) ?
                    ((DateTimeOffset.Now <= src.To) ? Status.Live : Status.Expired)
                    : src.Status;
        }



    }
}
