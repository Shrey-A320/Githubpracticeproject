﻿using AutoMapper;
using PPS.Client.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace PPS.ContentService.Core
{
    public class BaseService
    {
        internal readonly IMapper _mapper;

        public BaseService(IMapper mapper)
        {
            _mapper = mapper;
        }
        internal TDestination CallAndMap<TSource, TDestination>(ApiRequest<TSource> request)
        {
            return _mapper.Map<TDestination>(request.CallSync());
        }

    }
}
