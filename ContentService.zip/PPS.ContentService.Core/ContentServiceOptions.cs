using PPS.ContentService.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace PPS.ContentService.Core
{
    public class ContentServiceOptions
    {
        public string AppToken { get; set; }
        public string AuthUrl { get; set; }
        public string ApplicationName { get; set; }
        public string UserServiceUrl { get; set; }
        public CosmosSettings CosmosSettings { get; set; }
        public int DefaultStartDateDaysPrior { get; set; }
        public int CacheReload { get; set; }

    }

  
}
