﻿using System;
using System.Threading.Tasks;
using PPS.ContentService.Contracts;


namespace PPS.ContentService.Core
{
    public interface IUserContextService
    {
        UserContext GetUserContext(string userId);
        Task<DateTime> GetSplashLastChecked(string userId, string key);
        Task UpdateLastChecked(string userId, string key);
        void ClearCache();
        Service GetService(string serviceId);
    }

}
