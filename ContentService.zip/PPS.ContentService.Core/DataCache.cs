//using PPS.ProductUpgrades.Core.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PPS.Web.Core.Caching;

namespace  PPS.ContentService.Core
{

    public class DataCache<T> : AsyncDataCache<string, IEnumerable<T>>
    {

        private readonly Func<Task<IEnumerable<T>>> _getter;

        public DataCache(Func<Task<IEnumerable<T>>> getter): base(new TimeSpan(0, 0, 30, 0), new TimeSpan(1, 0, 0, 0)){
            _getter = getter;
        }

        protected override async Task<IEnumerable<T>> GetFromSource(string context)
        {
            return await _getter();
        }

        public IEnumerable<T> Where(Func<T, bool> predicate)
        {
            return this.Get("").Result.Data.Where(predicate);
        }

        public IEnumerable<T> All()
        {
            var result = this.Get("").Result;
            return result!=null ? result.Data:new T[0];
        }

    }

    public class DataCache<TK, T> : AsyncDataCache<TK, T>
    {
        private readonly Func<TK, Task<T>> _getter;

        public DataCache(Func<TK, Task<T>> getter, TimeSpan? expiry = null, TimeSpan? cleanUp = null)
            : base(expiry.HasValue ? expiry.Value : new TimeSpan(0, 0, 5, 0),
                  cleanUp.HasValue ? cleanUp.Value : new TimeSpan(0, 3, 0, 0))
        {
            _getter = getter;
        }

        public DataCache(Func<TK, Task<T>> getter) : base(new TimeSpan(0, 0, 5, 0), new TimeSpan(0, 3, 0, 0))
        {
            _getter = getter;
        }

        public T GetById(TK id) {
            var result = this.Get(id).Result;
            return result!=null?result.Data:default(T);
        }

        protected override async Task<T> GetFromSource(TK userId)
        {
            return await _getter(userId);
        }
    }

}