﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using PPS.ContentService.Contracts;

namespace PPS.ContentService.Core
{
    public interface ISplashService
    {
        Task<Splash> GetSplash(string splashId);
        Task<PagedResults<Splash>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status=null);
        Task<string> UpsertSplash(string userId, Splash splash);
        Task<bool> DeleteSplash(string splashId);
        Task<Response> PublishSplash(string userId, string splashId);
        /*splash screen*/
        Task<IEnumerable<Splash>> GetSplashes(string userId, ApplicationContext context);
        Task<bool> ViewSplash(string userId, ApplicationContext context);
        Splash GetCachedSplash(ApplicationContext context, string splashId);
        void ClearCache();
    }

}
