﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using PPS.ContentService.Contracts;
using System.Threading.Tasks;
using PPS.ContentService.Data.Repositories;
using System.ComponentModel.DataAnnotations;
using PPS.ContentService.Core.Helpers;
using Microsoft.Extensions.Options;

namespace PPS.ContentService.Core
{
    public class SplashService : BaseService, ISplashService
    {
        private readonly ISplashRepository _repository;
        IUserContextService _userContextService;
        private readonly DataCache<ApplicationContext, IEnumerable<Splash>> _splashCache;
        private readonly ContentServiceOptions _options;

        public SplashService(ISplashRepository repository, IUserContextService userContextService, IMapper mapper, IOptions<ContentServiceOptions> options) : base(mapper)
        {
            _repository = repository;
            _userContextService = userContextService;
            _options = options.Value;
            _splashCache = new DataCache<ApplicationContext, IEnumerable<Contracts.Splash>>((ApplicationContext context) => GetSplashesByContext(context), null, new TimeSpan(0, _options.CacheReload, 0) );
        }
        public async Task<Splash> GetSplash(string splashId)
            => _mapper.Map<Splash>(await _repository.GetSplash(splashId));

        public async Task<PagedResults<Splash>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status = null)
            => _mapper.Map<PagedResults<Splash>>((await _repository.GetSplashes(System.Web.HttpUtility.UrlDecode(continuationToken), take, term, status)));

        public async Task<string> UpsertSplash(string userId, Splash splash)
            => await _repository.UpsertSplash(userId, _mapper.Map<SplashDocument>(splash));

        public async Task<bool> DeleteSplash(string splashId)
            => await _repository.DeleteSplash(splashId);

        public async Task<Response> PublishSplash(string userId, string splashId)
        {
            var splash = await _repository.GetSplash(splashId);
            
            if(splash.Status == Status.Draft) {
                var isValid = ValidationHelper.Validate(splash);
                if (!isValid.Success)
                    return isValid;
                splash.Status = Status.Published;
                splash.Published = DateTime.Now;
            }
            else
            {
                splash.Status = Status.Draft;
                splash.Published = null;
            }
            return new Response() { Success = await _repository.UpsertSplash(userId, splash)!=null};
        }

        public async Task<IEnumerable<Splash>> GetSplashes(string userId, ApplicationContext context)
        {
            string key = $"{context}_splash";
            var user = _userContextService.GetUserContext(userId);
            if (user == null)
                return Array.Empty<Splash>();

            var service = _userContextService.GetService(user.ServiceId);

            Func<Splash, Service, bool> checkServiceAccountType = (spl, serv) =>
            {
                return spl.ServiceType == ServiceAccountType.Hybrid || 
                    (spl.ServiceType == ServiceAccountType.Sma && (serv.ServiceType == ServiceAccountType.Sma || serv.ServiceType == ServiceAccountType.Hybrid)) ||
                    (spl.ServiceType == ServiceAccountType.Vma && (serv.ServiceType == ServiceAccountType.Vma || serv.ServiceType == ServiceAccountType.Hybrid)) ||
                    (spl.ServiceType == ServiceAccountType.SmaOnly && (serv.ServiceType == ServiceAccountType.Sma)) ||
                    (spl.ServiceType == ServiceAccountType.VmaOnly && (serv.ServiceType == ServiceAccountType.Vma));
            };

            var minPublishedDate = await _userContextService.GetSplashLastChecked(userId, key);
            var now = DateTimeOffset.Now.ToUtc();
            var splashes = _splashCache.GetById(context);
            return splashes
                .Where( splash => 
                    splash.Published.Value.ToUtc() > minPublishedDate && 
                    splash.From < now && 
                    splash.To.Value.ToUtc() > now && splash.Regions.Contains(user.Region) &&
                    checkServiceAccountType(splash, service)
                    && !(splash.ExcludedServices.Any((es) =>  user.ServiceId == es || (_userContextService.GetService(es).ChildServices ?? Array.Empty<string>()).Contains(user.ServiceId) ) )
                )
                .Select(s=> new Splash() { Id = s.Id });
        }

        public async Task<bool> ViewSplash(string userId, ApplicationContext context)
        {
            string key = $"{context}_splash";
            await _userContextService.UpdateLastChecked(userId, key);
            return true;
        }

        public void ClearCache()
            => _splashCache.Clear();

        public Splash GetCachedSplash(ApplicationContext context, string splashId)
            => _splashCache.GetById(context).First(s=>s.Id == splashId);

        private async Task<IEnumerable<Splash>> GetSplashesByContext(ApplicationContext context)
            => (await _repository.GetSplashes(context, Status.Live)).Select(s=> _mapper.Map<Splash>(s));

        

    }
}
