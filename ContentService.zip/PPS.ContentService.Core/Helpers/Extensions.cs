using System;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using PPS.ContentService.Core.Mapper;
using PPS.ContentService.Data;
using PPS.UserService.Client;

namespace PPS.ContentService.Core
{
    public static class Extensions
    {
        
        public static void UseContentServiceCore(this IServiceCollection services, Action<ContentServiceOptions> setupAction = null)
        {

            var options = new ContentServiceOptions();
            setupAction?.Invoke(options);
            if (setupAction != null)
            {
                services.ConfigureAll<ContentServiceOptions>(setupAction);
            }
            services.UseContentServiceCore(options);
        }

        public static void UseContentServiceCore(this IServiceCollection services, ContentServiceOptions options)
        {
            
            services.AddSingleton<IMapper>(GetAutoMapperConfiguration().CreateMapper());
            services.AddSingleton<ISplashService, SplashService>();
            services.AddSingleton<IUserContextService, UserContextService>();

            var userServiceClient = new UserServiceClient(options.UserServiceUrl, options.AppToken);
            services.AddSingleton<IUserService>(userServiceClient);

            // uncomment and config if using external service
            //var externalServiceClient = new ExternalServiceClient(options.ExternalServiceUrl, options.AppToken);
            //services.AddSingleton<IExternalServiceClient>(externalServiceClient);
            // uncomment if using cosmos db
            services.UseContentServiceData(options.CosmosSettings);
        }

        public static AutoMapper.IConfigurationProvider GetAutoMapperConfiguration()
        {
            return new MapperConfiguration(cfg =>
            {
                cfg.AddMaps(typeof(ContentServiceProfile).Assembly);
            });
        }
    }
}
