﻿using PPS.ContentService.Contracts;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace PPS.ContentService.Core.Helpers
{
    public class ValidationHelper
    {

        public static Response Validate(object o)
        {
            var context = new System.ComponentModel.DataAnnotations.ValidationContext(o, serviceProvider: null, items: null);
            List<ValidationResult> results = new List<ValidationResult>();
            if (!Validator.TryValidateObject(o, context, results, true))
            {
                var messages = results.ToDictionary(i => {
                    var member = i.MemberNames.First();
                    return member.Substring(0, 1).ToLower() + member.Substring(1);
                    }, i => i.ErrorMessage);
                return new Response() { Success = false, Messages = messages };
            }
            return new Response() { Success = true };
        }

    }
}
