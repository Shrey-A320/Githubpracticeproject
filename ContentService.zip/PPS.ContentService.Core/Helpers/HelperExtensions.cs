﻿using RestSharp;
using System;
using System.Threading.Tasks;
using PPS.Client.Core;
namespace PPS.ContentService.Core.Helpers
{

    public static partial class HelperExtensions
    {
        public async static Task<T> ExecuteAndProcess<T>(this ApiRequest<T> request, Func<ApiRequest<T>, ApiRequest<T>> transform = null)
        {
            if (transform != null)
                request = transform(request);
            try
            {
                var response = await request.Execute();
                return response.ResponseData;
            }
            catch(PraemiumClientApiException ex)
            {
                if (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return default(T);

                throw ex;
            }
            
        }

        public async static Task<IRestResponse> ExecuteAndProcess(this ApiRequest request, Func<ApiRequest, ApiRequest> transform = null)
        {
            if (transform != null)
                request = transform(request);

            try
            {
                var response = await request.Execute();
                return response.Response;
            }
            catch (PraemiumClientApiException ex)
            {
                if (ex.Response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return null;

                throw ex;
            }
        }


        public static DateTime ToUtc(this DateTimeOffset date) => TimeZoneInfo.ConvertTimeToUtc(date.DateTime);

        public static string ToConfigurationFormattedDate(this DateTime date)
        {
            return date.ToUnixTimestamp().ToString();
        }

        public static DateTime FromConfigurationFormattedDate(this string date)
        {
            return UnixTimestampToDateTime(double.Parse(date));
        }

        public static DateTime UnixTimestampToDateTime(double unixTime)
        {
            DateTime unixStart = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            long unixTimeStampInTicks = (long)(unixTime * TimeSpan.TicksPerSecond);
            return new DateTime(unixStart.Ticks + unixTimeStampInTicks, System.DateTimeKind.Utc);
        }

        public static double ToUnixTimestamp(this DateTime dateTime)
        {
            return Math.Floor((TimeZoneInfo.ConvertTimeToUtc(dateTime) - new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc)).TotalSeconds);
        }
    }


}
