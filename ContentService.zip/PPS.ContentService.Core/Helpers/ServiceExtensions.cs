﻿using PPS.Client.Core;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPS.ContentService.Core
{

    public static partial class ServiceExtensions
    {
        public static T CallSync<T>(this ApiRequest<T> req)
        {
            var res = Task.Run<ApiResponse<T>>(() =>
            {
                return req.Execute();
            }).Result.ResponseData;
            return res;
        }

        public static IRestResponse CallSync(this ApiRequest req)
        {
            var res = Task.Run<ApiResponse>(() =>
            {
                return req.Execute();
            }).Result.Response;
            return res;
        }

    }


}
