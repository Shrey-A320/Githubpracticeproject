using Microsoft.Azure.Cosmos;
using System;
using System.Threading.Tasks;
using Serilog;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Azure.Cosmos.Linq;
using PPS.Cosmos.Core;
using System.Collections.ObjectModel;

namespace PPS.ContentService.Data
{
    public static class CosmosHelper
    {
        public static string ContentServiceDb { get; private set; } = "ContentService";
        public static string ContentServiceCollection { get; } = "ContentCollection";
        public const int DEFAULT_RETRY_AFTER_MILLISECONDS = 200;

        public static CosmosClient GetCosmosClient(CosmosSettings cosmosSettings, bool waitUntillInit = false)
        {
            Log.Information("Constructing cosmos document client.");
            var client = new CosmosClient(cosmosSettings.Url, cosmosSettings.ConnectionKey, new CosmosClientOptions
            {
                ConnectionMode = ConnectionMode.Gateway,
                GatewayModeMaxConnectionLimit = 1000,
                RequestTimeout = TimeSpan.FromMinutes(1),
                MaxRetryAttemptsOnRateLimitedRequests = 10,
                MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromMinutes(1)
            });
            Log.Information("Initializing databases and collections.");
            if(waitUntillInit)
                Task.Run(() => TryInitializeCollections(client)).Wait();
            else
                Task.Run(() => TryInitializeCollections(client));

            return client;
        }

        private static async Task TryInitializeCollections(CosmosClient client)
        {
            try
            {
                Log.Debug("Attempting to create {@ContentServiceDb} database if it does not exist", ContentServiceDb);
                var ContentServiceDB = await client.CreateDatabaseIfNotExistsAsync(ContentServiceDb);

                Log.Debug("Attempting to create {@ContentServiceCollection} collection if it does not exist", ContentServiceCollection);
                var indexingPolicy = new IndexingPolicy();
                indexingPolicy.CompositeIndexes.Add(new Collection<CompositePath>() { 
                    new CompositePath(){ Path = "/Status" },
                    new CompositePath(){ Path = "/From", Order = CompositePathSortOrder.Descending },
                });

                await ContentServiceDB.Database.CreateContainerIfNotExistsAsync(new ContainerProperties
                {
                    Id = ContentServiceCollection,
                    PartitionKeyPath = "/partition", 
                    IndexingPolicy = indexingPolicy
                });
            }
            catch (Exception e)
            {
                Log.Error(e, "An unexpected error occured while trying to initialize the templates databases and collections");
            }
        }

        public static async Task<List<T>> ToListAsync<T>(this IQueryable<T> queriable)
        {
            var results = new List<T>();
            var setIterator = queriable.ToFeedIterator();
            while (setIterator.HasMoreResults)
            {
                results.AddRange(await setIterator.ReadNextAsync());
            }
            return results;
        }

        public static string GetPartitionKeyString(string id)
        {
            return id.Substring(0, 2);
        }

        public static PartitionKey GetPartitionKey(string id)
        {
            return new PartitionKey(GetPartitionKeyString(id));
        }
    }
}
