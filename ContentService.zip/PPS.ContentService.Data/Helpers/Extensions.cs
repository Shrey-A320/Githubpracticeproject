using System;
using Microsoft.Extensions.DependencyInjection;
using PPS.ContentService.Data.Repositories;

namespace PPS.ContentService.Data
{
    public static class Extensions
    {
        public static void UseContentServiceData(this IServiceCollection services, CosmosSettings cosmosSettings, bool waitUntillInit = false)
        {

            services.AddSingleton(CosmosHelper.GetCosmosClient(cosmosSettings, waitUntillInit));
            services.AddSingleton<ISplashRepository, SplashRepository>();
            services.AddSingleton<IMemoryStreamManager, MemoryStreamManager>();

        }
    }
}
