﻿using System.IO;

namespace PPS.ContentService.Data
{
    public interface IMemoryStreamManager
    {
        Stream ToStream<T>(T input);
    }
}
