﻿using Microsoft.Azure.Cosmos;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PPS.ContentService.Data.Repositories
{
    public class BaseRepository
    {

        protected async Task<bool> ExeceuteAndRetry(Func<Task<bool>> func)
        {
            var result = false;
            try
            {
                result = await func();
            }
            catch (CosmosException exception) when (exception.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                result = true;
            }
            catch (CosmosException exception) when (exception.StatusCode == (System.Net.HttpStatusCode)429 || exception.StatusCode == (System.Net.HttpStatusCode)449)
            {
                await RetryAfter(exception.RetryAfter);
                result = await func();
            }
            catch (Exception exception)
            {
                Log.Fatal(exception.ToString());
                throw;
            }
            return result;
        }

        private async Task RetryAfter(TimeSpan? retryAfter)
        {
            await Task.Delay(retryAfter.HasValue ? retryAfter.Value : TimeSpan.FromMilliseconds(CosmosHelper.DEFAULT_RETRY_AFTER_MILLISECONDS));
        }


    }
}
