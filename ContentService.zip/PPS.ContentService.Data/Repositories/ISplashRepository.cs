﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PPS.ContentService.Contracts;

namespace PPS.ContentService.Data.Repositories
{
    public interface ISplashRepository
    {
        Task<SplashDocument> GetSplash(string splashId);
        Task<PagedResults<SplashDocument>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status = null);
        Task<string> UpsertSplash(string userId, SplashDocument splash);
        Task<bool> DeleteSplash(string splashId);
        /*splash screen*/
        Task<IEnumerable<SplashDocument>> GetSplashes(ApplicationContext context, Status? status);

    }
}
