﻿using Microsoft.Azure.Cosmos;
using PPS.Cosmos.Core;
using PPS.ContentService.Contracts;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;
using System;
using Microsoft.Azure.Cosmos.Linq;
using System.Linq.Expressions;

namespace PPS.ContentService.Data.Repositories
{
    public partial class SplashRepository : ISplashRepository
    {
        private readonly CosmosClient _client;
        private readonly IMemoryStreamManager _memoryStreamManager;

        public SplashRepository(CosmosClient client, IMemoryStreamManager memoryStreamManager) {
            _client = client;
            _memoryStreamManager = memoryStreamManager;
        }

        public async Task<SplashDocument> GetSplash(string splashId)
        {
            var container = _client.GetContainer(CosmosHelper.ContentServiceDb, CosmosHelper.ContentServiceCollection);

            var (items, continuationTokenRes) = await ExecuteQuery(container.GetItemLinqQueryable<SplashDocument>(false).Where(i => i.Id.Equals(splashId)));
            return items.FirstOrDefault();

        }

        public async Task<IEnumerable<SplashDocument>> GetSplashes(ApplicationContext context, Status? status = null)
        {
            var container = _client.GetContainer(CosmosHelper.ContentServiceDb, CosmosHelper.ContentServiceCollection);

            var queryable = container.GetItemLinqQueryable<SplashDocument>(false, null, new QueryRequestOptions{ });
            var query = BuildQueryBySearchTypes(queryable, null, Status.Live);
            var (items, continuationTokenRes) = await ExecuteQuery(query.Where(s => s.Applications.Contains(context)));
            return items;
        }

        public async Task<PagedResults<SplashDocument>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status=null)
        {
            
            if (take > 50) throw new InvalidOperationException($"Cannot take more than 50 items, {take} were asked for.");

            var container = _client.GetContainer(CosmosHelper.ContentServiceDb, CosmosHelper.ContentServiceCollection);

            var queryable = container.GetItemLinqQueryable<SplashDocument>(false, continuationToken, new QueryRequestOptions {
                MaxItemCount = take
            });


            var query = BuildQueryBySearchTypes(queryable, term, status);
            try
            {
                var (items, continuationTokenRes) = await ExecuteQuery(query.Select(s => new SplashDocument()
                {
                    Name = s.Name,
                    Id = s.id,
                    Description = s.Description,
                    From = s.From,
                    To = s.To, 
                    Status = s.Status
                }));

                return new PagedResults<SplashDocument>() { ContinuationToken = continuationTokenRes, Items = items };

            }catch(Exception e)
            {
                throw e;
            }


        }

        private IQueryable<SplashDocument> BuildQueryBySearchTypes(IOrderedQueryable<SplashDocument> query,string term, Status? status=null)
        {
            if (string.IsNullOrWhiteSpace(term) && status == null)
                return query.OrderBy(i => i.Status)
                    .ThenByDescending(i => i.From);

            var parameterExpression = Expression.Parameter(typeof(Splash), "a");
            var statusExpression = Expression.Property(parameterExpression, typeof(Splash).GetProperty("Status"));
            var fromExpression = Expression.Property(parameterExpression, typeof(Splash).GetProperty("From"));
            var toExpression = Expression.Property(parameterExpression, typeof(Splash).GetProperty("To"));
            var todayExpression = Expression.Constant((DateTimeOffset?)DateTimeOffset.Now.UtcDateTime, typeof(DateTimeOffset?));

            Expression current = Expression.Constant(true);
            switch (status)
            {
                case Status.Draft:
                    current = Expression.Equal(statusExpression, Expression.Constant(Status.Draft));
                    break;
                case Status.Published:
                    current = Expression.AndAlso(Expression.Equal(statusExpression, Expression.Constant(Status.Published)),
                        Expression.LessThan(todayExpression, fromExpression));
                    break;
                case Status.Live:
                    current = Expression.AndAlso(Expression.Equal(statusExpression, Expression.Constant(Status.Published)),
                        Expression.AndAlso( 
                            Expression.GreaterThanOrEqual(todayExpression, fromExpression),
                            Expression.LessThanOrEqual(todayExpression, toExpression))
                        );
                    break;
                case Status.Expired:
                    current = Expression.AndAlso(Expression.Equal(statusExpression, Expression.Constant(Status.Published)),
                        Expression.GreaterThan(todayExpression, toExpression));
                break;
            }

            if (!string.IsNullOrEmpty(term))
                current=Expression.AndAlso(current, 
                    Expression.OrElse(GetToUpperContainsExpression(parameterExpression, "Name", term), GetToUpperContainsExpression(parameterExpression, "Description", term))
                    );
            
            var whereCallExpression = Expression.Call(typeof(Queryable),
                                                      "Where",
                                                      new Type[] { query.ElementType },
                                                      query.Expression,
                                                      Expression.Lambda<Func<SplashDocument, bool>>(current, new ParameterExpression[] { parameterExpression }));


            return query.OrderBy(i => i.Status)
                    .ThenByDescending(i => i.From)
                    .Provider.CreateQuery<SplashDocument>(whereCallExpression);

        }

        private Expression GetToUpperContainsExpression(ParameterExpression parameterExpression, string property, string term)
        {
            return Expression.Call(Expression.Call(Expression.PropertyOrField(parameterExpression, property), "ToUpper", Type.EmptyTypes), "Contains", Type.EmptyTypes, Expression.Constant(term.ToUpper()));
            //var contains = Expression.PropertyOrField(parameterExpression, typeof(string).GetProperty("Status"))
            //return Expression.Call(Expression.PropertyOrField(parameterExpression, "Name"), "Contains", Type.EmptyTypes, Expression.Constant(term));
        }

        private async Task<(IEnumerable<SplashDocument>, string)> ExecuteQuery(IQueryable<SplashDocument> query){
            try
            {
                var iterator = query.ToFeedIterator();
                var response = await iterator.ReadNextAsync();
                return (response, response.ContinuationToken);

            }
            catch (CosmosException exception) when (exception.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return (Array.Empty<SplashDocument>(),null);
            }
            catch (Exception exception)
            {
                Log.Fatal(exception.ToString());
                throw;
            }
        }


        public async Task<string> UpsertSplash(string userId, SplashDocument splash)
        {
            var container = _client.GetContainer(CosmosHelper.ContentServiceDb, CosmosHelper.ContentServiceCollection);
            
            return await UpsertSplashDocument(container, userId, splash);
        }

        public async Task<bool> DeleteSplash(string splashId)
        {
            var splash = await GetSplash(splashId);
            var container = _client.GetContainer(CosmosHelper.ContentServiceDb, CosmosHelper.ContentServiceCollection);
            return await ExeceuteAndRetry(async () =>
            {
                await container.DeleteItemAsync<SplashDocument>(splash.Id, CosmosHelper.GetPartitionKey(splash.partition));
                return true;
            });
        }
        private async Task<string> UpsertSplashDocument(Container container, string userId, SplashDocument splash)
        {
            if (splash.Id == null)
            {
                splash.Id = Guid.NewGuid().ToString();
                splash.Created = DateTime.Now;
                splash.CreatedBy = userId;
                splash.Updates = Array.Empty<Update>();
            }
            else
            {
                var updates = new List<Update>();
                var previousUpdates = (await this.GetSplash(splash.Id))?.Updates;
                if (previousUpdates != null)
                    updates.AddRange(previousUpdates);

                updates.Add(new Update() { UpdatedBy = userId, Updated = DateTime.Now });
                splash.Updates = updates.ToArray();
            }
            splash.Region = splash.ServiceId.ToUpper().Substring(0, 2);
            var done = await ExeceuteAndRetry(async () =>
            {
                var result = false;
                using (var streamPayload = _memoryStreamManager.ToStream(splash))
                {
                    using (var responseMessage = await container.UpsertItemStreamAsync(streamPayload, CosmosHelper.GetPartitionKey(splash.Region)))
                    {
                        responseMessage.EnsureSuccessStatusCode();
                        result = true;
                    }
                };
                return result;
            });
            return done ? splash.Id : null;
        }

        private async Task<bool> ExeceuteAndRetry(Func<Task<bool>> func)
        {
            var result = false;
            try
            {
                result = await func();
            }
            catch (CosmosException exception) when (exception.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                result = true;
            }
            catch (CosmosException exception) when (exception.StatusCode == (System.Net.HttpStatusCode)429 || exception.StatusCode == (System.Net.HttpStatusCode)449)
            {
                await RetryAfter(exception.RetryAfter);
                result = await func();
            }
            catch (Exception exception)
            {
                Log.Fatal(exception.ToString());
                throw;
            }
            return result;
        }

        private async Task RetryAfter(TimeSpan? retryAfter)
        {
            await Task.Delay(retryAfter.HasValue ? retryAfter.Value : TimeSpan.FromMilliseconds(CosmosHelper.DEFAULT_RETRY_AFTER_MILLISECONDS));
        }

       
    }
}
