﻿namespace PPS.ContentService.Data
{
    public class CosmosSettings : Cosmos.Core.CosmosSettings
    {
        public string DbName { get; set; }
        public int MaxRetryAttemptsOnRateLimitedRequests { get; set; }
        public int MaxRetryWaitTimeMinuteOnRateLimitedRequests { get; set; }
    }

}
