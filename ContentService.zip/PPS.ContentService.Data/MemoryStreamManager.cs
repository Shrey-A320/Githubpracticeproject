﻿using System;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Microsoft.IO;

namespace PPS.ContentService.Data
{
    public class MemoryStreamManager : IMemoryStreamManager
    {
        private readonly RecyclableMemoryStreamManager _recyclableMemoryStreamManager;
        private static Lazy<JsonSerializer> _serialiser => new Lazy<JsonSerializer>();

        public MemoryStreamManager()
        {
            _recyclableMemoryStreamManager = new RecyclableMemoryStreamManager();
        }

        public Stream ToStream<T>(T input)
        {
            var streamPayload = _recyclableMemoryStreamManager.GetStream();
            using (var streamWriter = new StreamWriter(streamPayload, Encoding.Default, 1024, true))
            {
                using (var writer = new JsonTextWriter(streamWriter))
                {
                    writer.Formatting = Formatting.None;
                    _serialiser.Value.Serialize(writer, input);
                    writer.Flush();
                    streamWriter.Flush();
                }
            }

            streamPayload.Position = 0;
            return streamPayload;
        }
    }
}
