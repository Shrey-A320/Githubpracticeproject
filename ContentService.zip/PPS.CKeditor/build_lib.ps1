$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
Remove-Item -ErrorAction Ignore -Recurse $dir\dist
npm install
npm run build