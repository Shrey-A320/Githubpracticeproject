$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
npm version patch
Copy-Item  $dir\package.json $dir\dist
npm run publish:lib