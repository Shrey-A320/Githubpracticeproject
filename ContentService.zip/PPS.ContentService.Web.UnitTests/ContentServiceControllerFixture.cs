using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using PPS.ContentService.Contracts;
using PPS.ContentService.Core;
using PPS.ContentService.Web.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PPS.ContentService.Web.UnitTests
{
    [TestFixture]
    public class ContentServiceControllerFixture
    {
        private SplashController _controller;
        private Mock<ISplashService> _mockContentService;
        private string userID = "userId";
        [SetUp]
        public void SetUp()
        {
            _mockContentService = new Mock<ISplashService>();

            _controller = new SplashController(_mockContentService.Object);
            _controller.ControllerContext.HttpContext = new DefaultHttpContext();
            _controller.ControllerContext.HttpContext.Request.Headers.Add("userID", userID);
        }

        [TearDown]
        public void TearDown()
        {
            _mockContentService.VerifyAll();
            _mockContentService.VerifyNoOtherCalls();
        }

        [Test]
        public async Task TestGetContentService()
        {
            var expectedId = "01";

            var expectedItem = new Splash();

            _mockContentService.Setup(ps => ps.GetSplash(expectedId)).ReturnsAsync(expectedItem);
            var actualResult = await _controller.GetSplash(expectedId);

           
            Assert.AreEqual(
                SimpleJson.SimpleJson.SerializeObject(expectedItem),
                SimpleJson.SimpleJson.SerializeObject(actualResult));
        }

        [Test]
        public async Task TestGetContentServices()
        {
            var expected = new PagedResults<Splash> { Items = new List<Splash>() { new Splash() } };

            _mockContentService.Setup(ps => ps.GetSplashes(null, 9, null, null)).ReturnsAsync(expected);
            var actualResult = await _controller.GetSplashes(null, 9, null, null);


            Assert.AreEqual(
                SimpleJson.SimpleJson.SerializeObject(expected),
                SimpleJson.SimpleJson.SerializeObject(actualResult));
        }

        [Test]
        public async Task TestAddContentService()
        {
            var actualItem = new Splash();
            var expectedItem = new Splash();
            var expectedRequest = expectedItem ;
            var response = "ID";
            _mockContentService.Setup(ps => ps.UpsertSplash(userID, expectedItem)).ReturnsAsync(response)
                .Callback<string, Splash>((id, item) => actualItem = item);

            
            var actualResult = await _controller.UpsertSplash(expectedRequest);

            Assert.AreEqual(actualResult, response);

        }

        
        [Test]
        public async Task TestDeleteContentService()
        {
            var id = "1";
            
            _mockContentService.Setup(ps => ps.DeleteSplash(id)).ReturnsAsync(true);

            var actualResult = await _controller.DeleteSplash(id);

            Assert.IsTrue(actualResult);
        }

    }
}