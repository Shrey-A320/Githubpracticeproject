using AutoMapper;
using Microsoft.Azure.Cosmos;
using NUnit.Framework;
using PPS.ContentService.Contracts;
using PPS.ContentService.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PPS.ContentService.Data.UnitTests.Repositories
{
    [TestFixture]
    public class SplashServiceFixture
    {
        private CosmosClient _cosmosClient;
        private SplashRepository _splashRepository;
        private IMapper _mapper; 

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            _cosmosClient = TestHelper.GetCosmosClient();
            _mapper = Core.Extensions.GetAutoMapperConfiguration().CreateMapper();
        }

        [OneTimeTearDown]
        public async Task OneTimeTearDown()
        {
            await _cosmosClient.CleanUp(SplashServiceTestProvider.PARTITION);
        }

        [SetUp]
        public async Task SetUp()
        {
            await _cosmosClient.CleanUp(SplashServiceTestProvider.PARTITION);
            _splashRepository = new SplashRepository(_cosmosClient, new MemoryStreamManager());
        }

        [Test, TestCaseSource(typeof(SplashServiceTestProvider), "GetSplashsTestCases")]
        public async Task<string> TestGetSplashs(string id)
        {

            await _splashRepository.UpsertSplash(SplashServiceTestProvider.TestSplashDocument1.CreatedBy, SplashServiceTestProvider.TestSplashDocument1);
            await _splashRepository.UpsertSplash(SplashServiceTestProvider.TestSplashDocument1.CreatedBy, SplashServiceTestProvider.TestSplashDocument2);

            var actualSplashDocument = await _splashRepository.GetSplash(id);

            actualSplashDocument.Updates = Array.Empty<Update>();
            return SimpleJson.SimpleJson.SerializeObject(actualSplashDocument);
        }


        [Test]
        public async Task TestAddContentService()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;

            // Test insertion.
            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);
            var actualSplashDocument = await _splashRepository.GetSplash(expectedSplashDocument1.id);

            Assert.AreEqual(
                SimpleJson.SimpleJson.SerializeObject(expectedSplashDocument1),
                SimpleJson.SimpleJson.SerializeObject(actualSplashDocument));

            // Test update change property
            //expectedSplashDocument1.property = "CHANGE";
            await _splashRepository.UpsertSplash(expectedSplashDocument1.id, expectedSplashDocument1);
            actualSplashDocument = await _splashRepository.GetSplash(expectedSplashDocument1.id);

            Assert.AreEqual(
                SimpleJson.SimpleJson.SerializeObject(expectedSplashDocument1),
                SimpleJson.SimpleJson.SerializeObject(actualSplashDocument));
        }

        [Test]
        public async Task TestDeleteContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;

            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);
            await _splashRepository.DeleteSplash(expectedSplashDocument1.id);

            var actualSplashDocuments = await _splashRepository.GetSplash(expectedSplashDocument1.id);

            Assert.AreEqual(null, actualSplashDocuments);
        }


        [Test]
        public async Task TestSearchContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;
            var term = "test";
            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);
            
            var actualSplashDocuments = await _splashRepository.GetSplashes(null, 9, term, Status.Draft);

            Assert.AreEqual(testByStatus(actualSplashDocuments.Items, Status.Draft), testByTerm(actualSplashDocuments.Items, term));
        }

        Func<IEnumerable<Splash>, Status, bool> testByStatus = (items, status) => items.All(i => i.Status == status);

        [Test]
        public async Task TestSearchByDraftContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;

            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);

            var actualSplashDocuments = await _splashRepository.GetSplashes(null, 9, null, Status.Draft);
            Assert.IsTrue(testByStatus(actualSplashDocuments.Items.Select(s => _mapper.Map<Splash>(s)), Status.Draft));
        }

        [Test]
        public async Task TestSearchByPublishedContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;
            expectedSplashDocument1.Status = Status.Published;
            expectedSplashDocument1.From = DateTime.Now.AddDays(1);
            
            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);

            var actualSplashDocuments = await _splashRepository.GetSplashes(null, 9, null, Status.Published);

            Assert.IsTrue(testByStatus(actualSplashDocuments.Items.Select(s => _mapper.Map<Splash>(s)), Status.Published));
        }

        [Test]
        public async Task TestSearchByLiveContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;
            expectedSplashDocument1.Status = Status.Published;
            expectedSplashDocument1.From = DateTime.Now.AddDays(-1);
            expectedSplashDocument1.To = DateTime.Now.AddDays(+1);
            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);

            var actualSplashDocuments = await _splashRepository.GetSplashes(null, 9, null, Status.Live);

            Assert.IsTrue(testByStatus(actualSplashDocuments.Items.Select(s => _mapper.Map<Splash>(s)), Status.Live));
        }

        [Test]
        public async Task TestSearchByExpiredContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;
            expectedSplashDocument1.Status = Status.Published;
            expectedSplashDocument1.From = DateTime.Now.AddDays(+1);
            expectedSplashDocument1.To = DateTime.Now.AddDays(+2);
            var done = await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);

            var actualSplashDocuments = await _splashRepository.GetSplashes(null, 9, null, Status.Expired);

            Assert.IsTrue(testByStatus(actualSplashDocuments.Items.Select(s => _mapper.Map<Splash>(s)), Status.Expired));
        }

        Func<IEnumerable<SplashDocument>, string,  bool> testByTerm = (items ,term) => items.All(i => i.Name.ToUpper().Contains(term.ToUpper()) || i.Description.ToUpper().Contains(term.ToUpper()));

        [Test]
        public async Task TestSearchByTermContentServiceDocuments()
        {
            var expectedSplashDocument1 = SplashServiceTestProvider.TestSplashDocument1;

            await _splashRepository.UpsertSplash(expectedSplashDocument1.CreatedBy, expectedSplashDocument1);
            var term = "test"; 
            var actualSplashDocuments = await _splashRepository.GetSplashes(null, 9, term);

            Assert.IsTrue(testByTerm(actualSplashDocuments.Items, term));
        }
    }

    public class SplashServiceTestProvider
    {
        public static string PARTITION = "TS";
        public static string CREATEDBY = "TS";
        public static SplashDocument TestSplashDocument1
        {
            get
            {
                return new SplashDocument
                {
                    Name = "test name",
                    Id = PARTITION + "1",
                    Region = PARTITION,
                    ServiceId = PARTITION,
                    CreatedBy = "TS01",
                    Updates = Array.Empty<Update>(),
                    Pds = Array.Empty<string>(),
                    UserLevels = Array.Empty<UserLevelContext>(),
                    Applications = Array.Empty<ApplicationContext>(),
                    Regions = Array.Empty<RegionContext>(),
                    Tags = Array.Empty<string>()
                };
            }
        }

        public static SplashDocument TestSplashDocument2
        {
            get
            {
                return new SplashDocument
                {
                    Id = PARTITION + "2",
                    Region = PARTITION,
                    ServiceId = PARTITION,
                    CreatedBy = "TS01",
                    Updates = Array.Empty<Update>(),
                    Pds = Array.Empty<string>(),
                    UserLevels = Array.Empty<UserLevelContext>(),
                    Applications = Array.Empty<ApplicationContext>(),
                    Regions = Array.Empty<RegionContext>(),
                    Tags = Array.Empty<string>()
                };
            }
        }

        public static IEnumerable<TestCaseData> GetSplashsTestCases
        {
            get
            {
                yield return new TestCaseData(TestSplashDocument1.Id)
                    .Returns(SimpleJson.SimpleJson.SerializeObject(TestSplashDocument1));

                yield return new TestCaseData(TestSplashDocument2.Id)
                    .Returns(SimpleJson.SimpleJson.SerializeObject(TestSplashDocument2));


            }
        }
    }
}