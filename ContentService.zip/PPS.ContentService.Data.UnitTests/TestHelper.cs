using Microsoft.Azure.Cosmos;
using PPS.ContentService.Contracts;
using PPS.ContentService.Core;
using PPS.ContentService.Data.UnitTests.Repositories;
using System.Linq;
using System.Threading.Tasks;

namespace PPS.ContentService.Data.UnitTests
{
    public static class TestHelper
    {
        public static ContentServiceOptions TestSettings
        {
            get
            {
                return new ContentServiceOptions() { 
                    UserServiceUrl = "https://localhost:8081",
                    CosmosSettings = new CosmosSettings
                {
                    Url = "https://localhost:8081",
                    ConnectionKey = "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==",
                    DbName = "ContentService",
                    MaxRu = 1000,
                    MaxRetryAttemptsOnRateLimitedRequests = 100,
                    MaxRetryWaitTimeMinuteOnRateLimitedRequests = 5,
                } };
            }
        }

        // This returns Azure Cosmos DB emulator.
        public static CosmosClient GetCosmosClient() => CosmosHelper.GetCosmosClient(TestSettings.CosmosSettings, true);

        public static async Task CleanUp(this CosmosClient cosmosClient, string partition = "")
        {
            var container = cosmosClient.GetContainer(CosmosHelper.ContentServiceDb, CosmosHelper.ContentServiceCollection);
            var queryRequestOptions = new QueryRequestOptions();
            if (!string.IsNullOrEmpty(partition))
            {
                queryRequestOptions.PartitionKey = CosmosHelper.GetPartitionKey(partition);
            }
            var acds = await container.GetItemLinqQueryable<SplashDocument>(requestOptions: queryRequestOptions ).Where(i=> i.partition==partition).ToListAsync();
            var tasks = acds.Select(ac => container.DeleteItemAsync<SplashDocument>(ac.id, CosmosHelper.GetPartitionKey(ac.partition), null, default));
            await Task.WhenAll(tasks);
        }
    }
}