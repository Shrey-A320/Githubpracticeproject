using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using PPS.ContentService.Data.Repositories;
using System.Threading.Tasks;

namespace PPS.ContentService.Data.UnitTests.Helpers
{
    public class ExtensionsFixture
    {
        private IServiceCollection _services;

        [SetUp]
        public void SetUp()
        {
            _services = new ServiceCollection();
        }

        [Test]
        public async Task TestUseContentServiceData()
        {
            _services.UseContentServiceData(TestHelper.TestSettings.CosmosSettings, true);

            var serviceProvider = _services.BuildServiceProvider();
            var cosmosClient = serviceProvider.GetService<CosmosClient>();
            var response = await cosmosClient.GetDatabase(TestHelper.TestSettings.CosmosSettings.DbName).GetContainer(CosmosHelper.ContentServiceCollection).ReadContainerAsync();
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.StatusCode);
            Assert.IsTrue(serviceProvider.GetService<ISplashRepository>() is SplashRepository);
        }
    }
}
