using Microsoft.AspNetCore.Http;
using PPS.Client.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PPS.ContentService.Web.Helpers
{
    public class PraemiumClientApiExceptionHandler
    {

        private readonly RequestDelegate request;

        public PraemiumClientApiExceptionHandler(RequestDelegate pipeline)
        {
            this.request = pipeline;
        }

        public Task Invoke(HttpContext context) => this.InvokeAsync(context); // Stops VS from nagging about async method without ...Async suffix.

        async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await this.request(context);
            }
            catch (PraemiumClientApiException exception)
            {
                context.Response.StatusCode = (int)exception.Response.StatusCode;
                context.Response.Headers.Clear();
            }
        }

    }
}
