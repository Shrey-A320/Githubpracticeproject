﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using PPS.Authentication.Web.Core;
using PPS.ContentService.Core;
using System.Threading.Tasks;
using PPS.ContentService.Contracts;
using PPS.GateKeeper.Api;
using Microsoft.AspNetCore.Authorization;

namespace PPS.ContentService.Web.Controllers
{
    [Route("splash")]
    [ApiController]
    [PpsAuthorize(PpsAuthSchemes.Token, TokenPermissionsAllowed = new string[] { "Read" })]

    public class SplashController : GatekeeperController
    {
        private readonly ISplashService _splashService;

        public SplashController(ISplashService splashService)
        {
            _splashService = splashService;
        }

        [HttpGet("{splashId}")]
        public async Task<Splash> GetSplash(string splashId)
            => await _splashService.GetSplash(splashId);

        [HttpGet]
        public async Task<PagedResults<Splash>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status=null)
            => await _splashService.GetSplashes(continuationToken, take, term, status);

        [HttpDelete("{splashId}")]
        public async Task<bool> DeleteSplash(string splashId)
            => await _splashService.DeleteSplash(splashId);

        [HttpPost]
        public async Task<string> UpsertSplash(Splash splash)
        {
            splash.ServiceId = this.GetServiceId();
            return await _splashService.UpsertSplash(this.GetUserId(), splash);
        }

        [HttpGet("publish/{splashId}")]
        public async Task<Response> PublishSplash(string splashId)
        {
            return await _splashService.PublishSplash(this.GetUserId(), splashId);
        }
        /*Splash screen*/
        [HttpGet("get/{context}")]
        public async Task<IEnumerable<Splash>> GetContextSplashes(ApplicationContext context)
            => await _splashService.GetSplashes(this.GetUserId(), context);

        [HttpGet("get/{context}/{splashId}")]
        public Splash GetCachedSplash(ApplicationContext context, string splashId)
            => _splashService.GetCachedSplash(context, splashId);

        [HttpGet("viewed/{context}")]
        public async Task<bool> ViewSplash(ApplicationContext context)
            => await _splashService.ViewSplash(this.GetUserId(), context);

        /*cache clear*/
        [HttpGet("clearcache")]
        public void ClearCache()
            => _splashService.ClearCache();

    }

}