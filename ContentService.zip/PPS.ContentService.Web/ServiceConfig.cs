﻿using PPS.Client.Core.Status;
using PPS.Monitoring.Web.AspNetCore.CommonSettings;

namespace PPS.ContentService.Web
{
    public class ServiceConfig : ServiceStatusLocalInfoBase
    {
        [EnvironmentInfoMember(InfoResolver.Token)]
        public string AppToken { get; set; }

        [EnvironmentInfoMember]
        public string AuthUrl { get; set; }

        [EnvironmentInfoMember]
        public string UserServiceUrl { get; set; }
        
    }
}
