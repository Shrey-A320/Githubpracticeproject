﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace PPS.ContentService.Web
{
    public class SwaggerStartup
    {
        public static void ConfigureSwaggerServices(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Content Service", Version = "v1" });

                c.AddSecurityDefinition("App Token Authentication", new OpenApiSecurityScheme()
                {
                    Description = "Authorise the request using an application token",
                    Name = "App Token",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey
                });

                var securityRequirement = new OpenApiSecurityRequirement();
                securityRequirement.Add(new OpenApiSecurityScheme() { Name = "x-pps-token" }, new List<string>());
                c.AddSecurityRequirement(securityRequirement);

                c.CustomOperationIds(apiDesc =>
                {
                    return apiDesc.TryGetMethodInfo(out System.Reflection.MethodInfo methodInfo) ? methodInfo.Name : null;
                });

            });
        }

        public static void ConfigureSwagger(IApplicationBuilder app)
        {
            string templateUrl = "/praemium-swag/{documentName}/swagger.json";
            app.UseSwagger(o => {
                o.SerializeAsV2 = true;
                o.RouteTemplate = templateUrl;
            });

            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = "praemium-swag";
                c.SwaggerEndpoint(templateUrl.Replace("{documentName}", "v1"), "Content Service V1");
            });
        }

    }
}
