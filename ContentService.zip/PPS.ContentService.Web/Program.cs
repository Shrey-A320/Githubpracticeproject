﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using PPS.Logging.AspNetCore;
using PPS.Logging.NetCore;
using PPS.Logging.NetCore.Sentry;

namespace PPS.ContentService.Web
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration(builder => {
                //builder.AddPpsAzureKeyVaultConfiguration(); // uncomment if JWT tokens will be used with gatekeeper
            }).ConfigureWebHostDefaults(builder=> {
                    builder.ConfigureKestrel(k =>
                    {
                        k.AddServerHeader = false;
                    }).ConfigurePpsLogging(configurationAction: (config, loggerConfig) => {
                    var appName = config["ApplicationName"];
                    loggerConfig.ConfigureSentry(config, options =>
                    {
                        options.ApplicationName = appName;
                        options.Release = $"content-service@{options.Release}";
                    });
                                                      
                });
                builder.UseStartup<Startup>();
            });
    }
}
