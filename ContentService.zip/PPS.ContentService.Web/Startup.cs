﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Logging;
using PPS.Authentication.Web.AppToken.AspNetCore;
using PPS.Authentication.Web.Core;
using PPS.Authentication.Web.Jwt;
using PPS.Logging.AspNetCore;
using PPS.Monitoring.Web.AspNetCore;
using PPS.ContentService.Core;
using PPS.ContentService.Data;
using PPS.ContentService.Web.Filters;
using PPS.ContentService.Web.Helpers;
using Serilog;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PPS.ContentService.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            _serviceConfig = Configuration.Get<ServiceConfig>();
        }

        private readonly ServiceConfig _serviceConfig;
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            services.Configure<AuthOptions>(options =>
            {
                options.AppToken = Configuration.GetValue<string>(nameof(options.AppToken));
                options.AuthUrl = Configuration.GetValue<string>(nameof(options.AuthUrl));
            });
            services.AddAuthentication()
                .AddPpsAppTokenAuthentication();

            services.AddTransient<RouteTemplateFilter>();
            services.AddMvc(o => o.Filters.AddService<RouteTemplateFilter>()).AddNewtonsoftJson(o =>
            {
                o.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
                o.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            });
            services.AddControllers();
            services.Configure<ApiBehaviorOptions>(options =>
            {
                // Automatic model validation would skip RouteTemplateFilter,
                // so suppressed here and added back as ValidateModelAttribute
                options.SuppressModelStateInvalidFilter = true;
            });

            services.UseContentServiceCore(options => {
                Configuration.Bind(options);
            });

            SwaggerStartup.ConfigureSwaggerServices(services);

            IdentityModelEventSource.ShowPII = true;

            services.AddTransient<ValidateModelAttribute>();
            services.AddApplicationInsightsTelemetry();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.EnvironmentName == "Development")
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHsts();
            app.UsePpsLogging(o => {
                o.ExcludeRequestContentWhen = (httpContext) => {
                    // Do not log request body to avoid OutOfMemoryException.
                    return new string[] { HttpMethod.Post.Method, HttpMethod.Put.Method }.Contains(httpContext.Request.Method);
                };
            });

            app.UsePpsServiceStatus(_serviceConfig, o => {
                o.AddDependantService("CosmosDB", async (c) =>
{                    try
                    {
                    var cosmosClient = (CosmosClient)app.ApplicationServices.GetService(typeof(CosmosClient));
                    await cosmosClient.GetDatabase(CosmosHelper.ContentServiceDb).ReadAsync();
                    return await Task.FromResult(true);
                    }
                    catch (Exception e)
                    {
                    Log.Fatal(e, "Was not able to performa a status check on templates's cosmos db");
                    return await Task.FromResult(false);
                    }
                    });
                o.AddDependantWebService("User Service", _serviceConfig.UserServiceUrl);
            });

            app.Use((context, request) =>
            {
                if (context.Request.Path == "/")
                {
                    NewRelic.Api.Agent.NewRelic.IgnoreTransaction();
                }

                return request();
            });

            app.UseRouting();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            SwaggerStartup.ConfigureSwagger(app);
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(c => c.MapControllers());
            
        }

    }
}
