﻿using PPS.Client.Core;
using PPS.ContentService.Contracts;
using System;
using System.Collections.Generic;

namespace PPS.ContentService.Client
{
    public interface IContentServiceClient
    {

        ApiRequest<Splash> GetSplashById(string splashId);
        ApiRequest<PagedResults<Splash>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status=null);
        ApiRequest<string> UpsertSplash(Splash splash);
        ApiRequest<bool> DeleteSplash(string splashId);
        ApiRequest<Response> PublishSplash(string splashId);
        /*Splash screen*/
        ApiRequest<IEnumerable<Splash>> GetSplashes(ApplicationContext context);
        ApiRequest<bool> ViewSplash(ApplicationContext context);
        ApiRequest<Splash> GetCachedSplash(ApplicationContext context, string splashId);
    }
}
