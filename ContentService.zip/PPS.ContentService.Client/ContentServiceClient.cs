﻿using PPS.Client.Core;
using PPS.Client.Core.Status;
using PPS.ContentService.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PPS.ContentService.Client
{
    public class ContentServiceClient : RestServiceBase, IContentServiceClient
    {
        private const string ClientApiName = "ContentService Service";
        public const string ClientApiVersion = "2019.31.07";
        public ContentServiceClient(string uri, string token)
           : base(ClientApiName, uri, token, ClientApiVersion, new RestServiceBaseOptions() { UseLegacyTokenHeader = false })
        {
            Status = new ServiceStatusClient(ClientApiName, uri, token, ClientApiVersion, new RestServiceBaseOptions() { UseLegacyTokenHeader = false });
        }
        public ServiceStatusClient Status { get; }

        public ApiRequest<Splash> GetSplashById(string splashId)
            => CreateGet<Splash>($"splash/{splashId}");
        public ApiRequest<PagedResults<Splash>> GetSplashes(string continuationToken = null, int take = 9, string term = null, Status? status = null)
            => CreateGet<PagedResults<Splash>>($"splash?continuationToken={continuationToken}&take={take}&term={term}&status={status}");
        public ApiRequest<string> UpsertSplash(Splash splash)
            => CreatePost<string>($"splash", splash);
        public ApiRequest<bool> DeleteSplash(string splashId)
            => CreateDelete<bool>($"splash/{splashId}", null);
        public ApiRequest<Response> PublishSplash(string splashId)
            => CreateGet<Response>($"splash/publish/{splashId}", null);

        /*Splash screen*/
        public ApiRequest<IEnumerable<Splash>> GetSplashes(ApplicationContext context)
            => CreateGet<IEnumerable<Splash>>($"splash/get/{context}");
        public ApiRequest<bool> ViewSplash(ApplicationContext context)
            => CreateGet<bool>($"splash/viewed/{context}");
        public ApiRequest<Splash> GetCachedSplash(ApplicationContext context, string splashId)
             => CreateGet<Splash>($"splash/get/{context}/{splashId}");

    }
}
