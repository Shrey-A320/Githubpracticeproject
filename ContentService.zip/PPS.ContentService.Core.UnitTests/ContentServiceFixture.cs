using AutoMapper;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;
using PPS.ContentService.Contracts;
using PPS.ContentService.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PPS.ContentService.Core.UnitTests
{
    [TestFixture]
    public class ContentServiceFixture
    {
        private Mock<ISplashRepository> _mockSplashService;
        private Mock<IUserContextService> _mockUserService;
        private IMapper _mapper;
        private SplashService _splashService;
        private IOptions<ContentServiceOptions> _options;

        [SetUp]
        public void SetUp()
        {
            _mockSplashService = new Mock<ISplashRepository>();
            _mockUserService = new Mock<IUserContextService>();
            _mapper = Core.Extensions.GetAutoMapperConfiguration().CreateMapper();
            _options = Options.Create<ContentServiceOptions>(new ContentServiceOptions());
            _splashService = new SplashService(_mockSplashService.Object, _mockUserService.Object, _mapper, _options);
        }

        [TearDown]
        public void TearDown()
        {
            _mockSplashService.VerifyAll();
            _mockSplashService.VerifyNoOtherCalls();
        }

        [Test]
        public async Task TestGetContentService()
        {
            var expectedSplashDocument = GetTestSplashDocument();
            var id = expectedSplashDocument.Id;

            _mockSplashService.Setup(pr => pr.GetSplash(id))
                .ReturnsAsync(expectedSplashDocument);

            var actualResults = await _splashService.GetSplash(id);

            var mapped = _mapper.Map<Splash>(expectedSplashDocument);
            Assert.AreEqual(
                SerializeObject(mapped),
                SerializeObject(actualResults));
        }

        [Test]
        public async Task TestGetContentServices()
        {
            var expectedSplashDocuments = new PagedResults<SplashDocument> { ContinuationToken ="TOKEN",  Items = new List<SplashDocument>() { GetTestSplashDocument() } };
            _mockSplashService.Setup(pr => pr.GetSplashes(null, 9, null, null))
                .ReturnsAsync(expectedSplashDocuments);

            var actualResults = await _splashService.GetSplashes(null, 9, null, null);

            Assert.AreEqual(1, actualResults.Items.Count());
            Assert.AreEqual(
                SerializeObject(expectedSplashDocuments.Items.Select(i=>_mapper.Map<Splash>(i))),
                SerializeObject(actualResults.Items));
        }

        [Test]
        public async Task TestAddContentService()
        {
            var expectedItemToAdd = GetTestSplashDocument();
            var userid = expectedItemToAdd.CreatedBy;
            var actualItemToUpdate = new SplashDocument();

            _mockSplashService.Setup(pr => pr.UpsertSplash(userid, It.IsAny<SplashDocument>()))
                .Callback<string, SplashDocument>((id, ItemToUpdate) => actualItemToUpdate = ItemToUpdate)
                .ReturnsAsync(expectedItemToAdd.Id);

            Assert.AreEqual(expectedItemToAdd.Id, await _splashService.UpsertSplash(userid, expectedItemToAdd));

            Assert.AreEqual(
                SerializeObject(expectedItemToAdd),
                SerializeObject(actualItemToUpdate));
        }

        [Test]
        public async Task TestUpdateContentService()
        {
            var expectedItemToUpdate = GetTestSplashDocument();
            var actualItemToUpdate = new SplashDocument();

            _mockSplashService.Setup(pr => pr.UpsertSplash(expectedItemToUpdate.CreatedBy, It.IsAny<SplashDocument>()))
                .Callback<string, SplashDocument>((id, ItemToUpdate) => actualItemToUpdate = ItemToUpdate)
                .ReturnsAsync(expectedItemToUpdate.Id);
            Assert.AreEqual(expectedItemToUpdate.Id, await _splashService.UpsertSplash(expectedItemToUpdate.CreatedBy, expectedItemToUpdate));
            Assert.AreEqual(
                SerializeObject(expectedItemToUpdate),
                SerializeObject(actualItemToUpdate));
        }

        [Test]
        public async Task TestDeleteContentService()
        {
            var expectedSplashDocument = GetTestSplashDocument();
            var serviceid = expectedSplashDocument.ServiceId;
            var id = expectedSplashDocument.id;
            _mockSplashService.Setup(cr => cr.DeleteSplash(id)).ReturnsAsync(true);

            var actualResult = await _splashService.DeleteSplash(id);

            Assert.IsTrue(actualResult);
        }


        private SplashDocument GetTestSplashDocument() => new SplashDocument
        {
            Id = "TS01",
            Region = "TS",ServiceId = "TS", CreatedBy ="TS01" , Updates = Array.Empty<Update>(), Pds = Array.Empty<string>(), 
            UserLevels = Array.Empty<UserLevelContext>(),
            Applications = Array.Empty<ApplicationContext>(),
            Regions = Array.Empty<RegionContext>(),
            Tags = Array.Empty<string>(), 
            ExcludedServices = Array.Empty<string>()
        };

        private string SerializeObject(object o)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(o, Newtonsoft.Json.Formatting.Indented, new Newtonsoft.Json.JsonSerializerSettings
            {
                NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore
            });
        }
    }
}