using AutoMapper;
using NUnit.Framework;
using Microsoft.Extensions.DependencyInjection;
using PPS.ContentService.Data.UnitTests;
using PPS.ContentService.Core;

namespace PPS.ContentService.Core.UnitTests.Helpers
{
    public class ExtensionsFixture
    {
        private IMapper _mapper;
        private IServiceCollection _services;

        [SetUp]
        public void SetUp()
        {
            _mapper = Extensions.GetAutoMapperConfiguration().CreateMapper();

            _services = new ServiceCollection();
            _services.UseContentServiceCore(opts => {
                opts.UserServiceUrl = TestHelper.TestSettings.UserServiceUrl;
                opts.CosmosSettings = TestHelper.TestSettings.CosmosSettings;
                });
        }

        [Test]
        public void TestUseContentServiceCore()
        {
            var serviceProvider = _services.BuildServiceProvider();
            Assert.IsTrue(serviceProvider.GetService<IMapper>() is AutoMapper.Mapper);
            Assert.IsTrue(serviceProvider.GetService<ISplashService>() is SplashService);
        }

        [Test]
        public void TestAutoMapperConfigurationIsValid()
        {
            _mapper.ConfigurationProvider.AssertConfigurationIsValid();
        }
    }
}
